// Spline Loft - placeable actor that sweeps a 2D bevel profile along its spline.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SplineLoftLibrary.h"
#include "SplineLoftActor.generated.h"

class USplineComponent;
class UProceduralMeshComponent;
class UMaterialInterface;

/** Cross-section presets. */
UENUM(BlueprintType)
enum class ESplineLoftProfileType : uint8
{
	/** Round tube. */
	Pipe		UMETA(DisplayName = "Pipe"),
	/** Rectangle with rounded / chamfered corners (BevelRadius). */
	Box			UMETA(DisplayName = "Box (bevel)"),
	/** Arc shell between Radius +/- Thickness/2. */
	HalfPipe	UMETA(DisplayName = "Half Pipe"),
	/** Flat open strip on the spline's right axis. */
	Ribbon		UMETA(DisplayName = "Ribbon"),
	/** Open strip on the spline's up axis. */
	RibbonVertical UMETA(DisplayName = "Ribbon (vertical)"),
	/** User supplied points. */
	Custom		UMETA(DisplayName = "Custom")
};

/** How UV0 is laid out. */
UENUM(BlueprintType)
enum class ESplineLoftUVMode : uint8
{
	/** The whole model spans 0..1: one texture around the profile and along the spline. */
	Normalized		UMETA(DisplayName = "Normalized (one UV for whole model)"),
	/** Tile by world length, controlled by Tile U / Tile V. */
	WorldTiling		UMETA(DisplayName = "World Tiling")
};

/**
 * Placeable spline loft.
 * Native spline + procedural mesh, rebuilt on construction and whenever a property or the spline changes.
 *
 * NOTE: no EditCondition is used on purpose - every size parameter is always visible and editable,
 * so nothing is ever greyed out / hidden by a broken condition string.
 */
UCLASS(Blueprintable, ClassGroup = (SplineLoft), meta = (DisplayName = "Spline Loft"))
class SPLINELOFT_API ASplineLoftActor : public AActor
{
	GENERATED_BODY()

public:
	ASplineLoftActor();

	// ---------------------------------------------------------------- components

	/** Path. This is the root component. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Spline Loft|Components")
	TObjectPtr<USplineComponent> Spline;

	/** Generated mesh (one section, one draw call). */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Spline Loft|Components")
	TObjectPtr<UProceduralMeshComponent> LoftMesh;

	// ---------------------------------------------------------------- profile

	/** Which cross-section to sweep. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Profile Type"))
	ESplineLoftProfileType ProfileType = ESplineLoftProfileType::Box;

	/**
	 * Custom cross-section, used when Profile Type = Custom.
	 * 2D points, X = spline right, Y = spline up (cm). Click the "+" to add, 3+ points for a closed profile.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Custom Profile Points"))
	TArray<FVector2D> CustomProfile;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Custom Profile Closed"))
	bool bClosedCustomProfile = true;

	/** Thickness of the Pipe / Half Pipe profile. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Radius (thickness)", ClampMin = "0.1"))
	float Radius = 50.f;

	/** Segments around the Pipe / Half Pipe profile. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Radial Segments", ClampMin = "3", ClampMax = "128"))
	int32 RadialSegments = 24;

	/** Box / Ribbon size along the spline's right axis. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Width", ClampMin = "0.1"))
	float Width = 100.f;

	/** Box size along the spline's up axis (Ribbon vertical length). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Height", ClampMin = "0.1"))
	float Height = 100.f;

	/** Box corner radius. 0 = sharp, 1 segment = chamfer. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Bevel Radius", ClampMin = "0.0"))
	float BevelRadius = 10.f;

	/** Segments per box corner. 1 = chamfer, 2+ = round. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Bevel Segments", ClampMin = "1", ClampMax = "16"))
	int32 BevelSegments = 4;

	/** Half Pipe wall thickness. 0 = open arc. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Half Pipe Thickness", ClampMin = "0.0"))
	float Thickness = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Arc Start Angle"))
	float ArcStartAngle = 180.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Arc End Angle"))
	float ArcEndAngle = 360.f;

	/** Uniform scale of the whole profile. A single knob for "how thick". */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile", meta = (DisplayName = "Profile Scale (overall size)", ClampMin = "0.01"))
	float ProfileScale = 1.f;

	/** Rotate the profile around the path (degrees, CCW). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile")
	float ProfileRotation = 0.f;

	/** Shift the profile relative to the path. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "1 Profile")
	FVector2D ProfileOffset = FVector2D::ZeroVector;

	// ---------------------------------------------------------------- path

	/** Curve adaptive rings: straight runs stay coarse, only curved parts get subdivided. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2 Path", meta = (DisplayName = "Adaptive Segments"))
	bool bAdaptivePath = true;

	/** Max deviation (cm) from the real curve. Smaller = more rings in the curves. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2 Path", meta = (DisplayName = "Curve Tolerance (cm)", ClampMin = "0.01"))
	float PathTolerance = 0.5f;

	/** Uniform ring spacing. Only used when Adaptive Segments is off. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2 Path", meta = (ClampMin = "1.0"))
	float PathStep = 25.f;

	/** Miter stretch limit. 90 degree corners need >= 1.414. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2 Path", meta = (ClampMin = "1.0", ClampMax = "16.0"))
	float MiterLimit = 4.f;

	/** How a corner that is tighter than the profile is resolved. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2 Path", meta = (DisplayName = "Corner Mode"))
	ESplineLoftCornerMode CornerMode = ESplineLoftCornerMode::Trim;

	/** Trim mode: tolerance (cm) for the inner offset self-intersection test. 0 = auto (2% of the profile). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "2 Path", meta = (DisplayName = "Trim Tolerance (cm)", ClampMin = "0.0"))
	float TrimTolerance = 0.f;

	/** Shrink mode: how much of the curvature radius is kept. Lower = narrower at corners. */

	/** Floor for Corner Mode = Shrink (fraction of the profile). */

	// ---------------------------------------------------------------- uv

	/** How UV0 is laid out. Normalized = the whole model is one 0..1 UV (no repeats). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3 UV")
	ESplineLoftUVMode UVMode = ESplineLoftUVMode::Normalized;

	/** U tile length in cm. Only used with UVMode = World Tiling. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3 UV", meta = (ClampMin = "0.01"))
	float TileU = 100.f;

	/** V tile length in cm. Only used with UVMode = World Tiling. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "3 UV", meta = (ClampMin = "0.01"))
	float TileV = 100.f;

	// ---------------------------------------------------------------- mesh

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4 Mesh")
	TObjectPtr<UMaterialInterface> Material;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4 Mesh")
	bool bCreateCollision = false;

	/** Flip triangle order. Only tick this if the surface still renders inside-out. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4 Mesh", meta = (DisplayName = "Flip Winding (inside-out fix)"))
	bool bFlipWinding = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "4 Mesh")
	bool bFlipNormals = false;

	// ---------------------------------------------------------------- api

	/** Rebuild the mesh from the current spline + settings. */
	UFUNCTION(BlueprintCallable, CallInEditor, Category = "Spline Loft")
	void RebuildLoft();

	/** Switch to a round pipe and rebuild. One node for "make it a pipe". */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft|Presets")
	void UsePipeProfile(float InRadius = 50.f, int32 Segments = 24);

	/** Switch to a beveled box and rebuild. */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft|Presets")
	void UseBoxProfile(float InWidth = 100.f, float InHeight = 100.f, float Bevel = 10.f, int32 BevelSeg = 4);

	/** Switch to a flat / vertical ribbon and rebuild. */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft|Presets")
	void UseRibbonProfile(float InWidth = 100.f, bool bVertical = false);

	/** Switch to a half pipe shell and rebuild. */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft|Presets")
	void UseHalfPipeProfile(float InRadius = 100.f, float InThickness = 10.f, int32 Segments = 24);

	/** Feed your own 2D cross-section (X = spline right, Y = spline up) and rebuild. 3+ points for a closed outline. */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft|Presets")
	void UseCustomProfile(const TArray<FVector2D>& Points, bool bClosed = true);

	/** Profile used by the current settings (2D, spline space, already scaled). */
	UFUNCTION(BlueprintPure, Category = "Spline Loft")
	TArray<FVector2D> GetProfilePoints() const;

	UFUNCTION(BlueprintPure, Category = "Spline Loft")
	bool IsProfileClosed() const;

	UFUNCTION(BlueprintPure, Category = "Spline Loft")
	USplineComponent* GetSpline() const { return Spline; }

	UFUNCTION(BlueprintPure, Category = "Spline Loft")
	UProceduralMeshComponent* GetLoftMesh() const { return LoftMesh; }

protected:
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent) override;
	/** Tick in editor viewports so the mesh follows the spline while dragging points. */
	virtual bool ShouldTickIfViewportsOnly() const override { return true; }
#endif

private:
	/** Un-scaled profile for the current ProfileType. */
	TArray<FVector2D> BuildRawProfilePoints() const;

	/** Hash of everything that affects the generated mesh; used to rebuild while editing. */
	uint32 ComputeSettingsHash() const;

	uint32 LastHash = 0;
};

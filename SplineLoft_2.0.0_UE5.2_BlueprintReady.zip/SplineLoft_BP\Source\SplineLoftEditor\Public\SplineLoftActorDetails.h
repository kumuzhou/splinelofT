#pragma once

#include "CoreMinimal.h"
#include "IDetailCustomization.h"

/**
 * Pins the Profile / Path / UV / Mesh categories to the top of the details panel,
 * above the Spline and LoftMesh component sections.
 */
class FSplineLoftActorDetails : public IDetailCustomization
{
public:
	static TSharedRef<IDetailCustomization> MakeInstance();

	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
};

#include "SplineLoftActorFactory.h"

#include "SplineLoftActor.h"

UActorFactorySplineLoft::UActorFactorySplineLoft(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	NewActorClass = ASplineLoftActor::StaticClass();
	DisplayName = NSLOCTEXT("SplineLoft", "SplineLoftFactory", "Spline Loft");
	bUseSurfaceOrientation = false;
}

bool UActorFactorySplineLoft::CanCreateActorFrom(const FAssetData& AssetData, FText& OutErrorMsg)
{
	// Placeable without any asset (Place Actors panel / empty asset data).
	// Any real asset (a Blueprint, a mesh, a material...) is left to its own factory.
	if (AssetData.IsValid() && AssetData.GetClass() != UClass::StaticClass())
	{
		return false;
	}
	return true;
}

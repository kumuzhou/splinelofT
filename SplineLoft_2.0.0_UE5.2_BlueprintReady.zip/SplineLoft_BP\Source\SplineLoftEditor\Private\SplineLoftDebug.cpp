// Diagnostic console command: builds every profile type and logs vertex / triangle counts and bounds.
// Usage (editor console):  SplineLoft.SelfTest
//
// The actor is spawned into the current editor world and removed afterwards; the level's
// dirty flag is restored so running this never marks the map as modified.

#include "CoreMinimal.h"
#include "HAL/IConsoleManager.h"
#include "Editor.h"
#include "Engine/World.h"
#include "Components/SplineComponent.h"
#include "ProceduralMeshComponent.h"
#include "SplineLoftActor.h"
#include "SplineLoftBake.h"
#include "ProceduralMeshComponent.h"

DEFINE_LOG_CATEGORY_STATIC(LogSplineLoftTest, Log, All);

namespace
{
	void ReportProfile(ASplineLoftActor* Actor, const TCHAR* Label)
	{
		Actor->RebuildLoft();

		UProceduralMeshComponent* Mesh = Actor->GetLoftMesh();
		const FProcMeshSection* Section = (Mesh && Mesh->GetNumSections() > 0) ? Mesh->GetProcMeshSection(0) : nullptr;

		const int32 NumVerts = Section ? Section->ProcVertexBuffer.Num() : 0;
		const int32 NumTris = Section ? Section->ProcIndexBuffer.Num() / 3 : 0;
		const FVector Extent = Section ? Section->SectionLocalBox.GetExtent() : FVector::ZeroVector;

		FVector2D UVMin(FLT_MAX, FLT_MAX);
		FVector2D UVMax(-FLT_MAX, -FLT_MAX);
		FVector N0 = FVector::ZeroVector;
		if (Section && Section->ProcVertexBuffer.Num() > 0)
		{
			N0 = Section->ProcVertexBuffer[0].Normal;
			for (const FProcMeshVertex& V : Section->ProcVertexBuffer)
			{
				UVMin.X = FMath::Min(UVMin.X, V.UV0.X);
				UVMin.Y = FMath::Min(UVMin.Y, V.UV0.Y);
				UVMax.X = FMath::Max(UVMax.X, V.UV0.X);
				UVMax.Y = FMath::Max(UVMax.Y, V.UV0.Y);
			}
		}

		TSet<FIntVector> Unique;
		uint32 PosHash = 0;
		if (Section)
		{
			for (const FProcMeshVertex& V : Section->ProcVertexBuffer)
			{
				Unique.Add(FIntVector(FMath::RoundToInt(V.Position.X), FMath::RoundToInt(V.Position.Y), FMath::RoundToInt(V.Position.Z)));
				PosHash = HashCombine(PosHash, GetTypeHash(FIntVector(FMath::RoundToInt(V.Position.X), FMath::RoundToInt(V.Position.Y), FMath::RoundToInt(V.Position.Z))));
			}
		}

		UE_LOG(LogSplineLoftTest, Display, TEXT("[SplineLoft] %-16s verts=%4d tris=%4d uniq=%4d hash=%08x extent=(%.1f, %.1f, %.1f) uvU=[%.3f..%.3f] uvV=[%.3f..%.3f] n0=(%.2f, %.2f, %.2f)"),
			Label, NumVerts, NumTris, Unique.Num(), PosHash, Extent.X, Extent.Y, Extent.Z, UVMin.X, UVMax.X, UVMin.Y, UVMax.Y, N0.X, N0.Y, N0.Z);
	}
}

static void SplineLoftSelfTest()
{
	UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
	if (!World)
	{
		UE_LOG(LogSplineLoftTest, Error, TEXT("[SplineLoft] self-test: no editor world"));
		return;
	}

	UPackage* LevelPackage = World->GetOutermost();
	const bool bWasDirty = LevelPackage ? LevelPackage->IsDirty() : false;

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnParams.ObjectFlags |= RF_Transient;

	ASplineLoftActor* Actor = World->SpawnActor<ASplineLoftActor>(ASplineLoftActor::StaticClass(), FTransform::Identity, SpawnParams);
	if (!Actor)
	{
		UE_LOG(LogSplineLoftTest, Error, TEXT("[SplineLoft] self-test: spawn failed"));
		return;
	}

	Actor->ProfileScale = 1.f;

	Actor->ProfileType = ESplineLoftProfileType::Box;
	Actor->Width = 200.f;
	Actor->Height = 100.f;
	Actor->BevelRadius = 0.f;
	ReportProfile(Actor, TEXT("Box 200x100"));

	Actor->ProfileType = ESplineLoftProfileType::Pipe;
	Actor->Radius = 30.f;
	Actor->RadialSegments = 24;
	ReportProfile(Actor, TEXT("Pipe r30 /24"));

	Actor->RadialSegments = 48;
	ReportProfile(Actor, TEXT("Pipe r30 /48"));

	Actor->ProfileType = ESplineLoftProfileType::HalfPipe;
	Actor->Radius = 100.f;
	Actor->Thickness = 10.f;
	ReportProfile(Actor, TEXT("HalfPipe r100"));

	Actor->ProfileType = ESplineLoftProfileType::Ribbon;
	Actor->Width = 200.f;
	ReportProfile(Actor, TEXT("Ribbon w200"));

	Actor->ProfileType = ESplineLoftProfileType::Pipe;
	Actor->Radius = 30.f;
	Actor->ProfileScale = 2.f;
	ReportProfile(Actor, TEXT("Pipe r30 x2"));

	Actor->ProfileScale = 1.f;
	Actor->UVMode = ESplineLoftUVMode::WorldTiling;
	Actor->TileV = 100.f;
	ReportProfile(Actor, TEXT("Pipe r30 tiled"));

	// Sharp corner: Miter vs Fan should show the inner side collapsing onto one apex.
	{
		TArray<FVector> Corners;
		Corners.Add(FVector(0.f, 0.f, 0.f));
		Corners.Add(FVector(600.f, 0.f, 0.f));
		Corners.Add(FVector(1100.f, 500.f, 0.f));
		Actor->GetSpline()->SetSplinePoints(Corners, ESplineCoordinateSpace::Local, true);
		for (int32 i = 0; i < Actor->GetSpline()->GetNumberOfSplinePoints(); ++i)
		{
			Actor->GetSpline()->SetSplinePointType(i, ESplinePointType::Linear, true);
		}
		Actor->UseRibbonProfile(400.f, false);

		Actor->CornerMode = ESplineLoftCornerMode::Miter;
		ReportProfile(Actor, TEXT("V-ribbon miter"));
		Actor->CornerMode = ESplineLoftCornerMode::Trim;
		ReportProfile(Actor, TEXT("V-ribbon trim"));
	}
	// Bake path: must not assert on degenerate triangles.
	{
		UStaticMesh* Baked = SplineLoftBake::BuildStaticMeshAsset(Actor->GetLoftMesh(), TEXT("/Temp/SplineLoftBakeTest"), TEXT("SM_SelfTest"));
		UE_LOG(LogSplineLoftTest, Display, TEXT("[SplineLoft] bake test  %s tris=%d"), Baked ? TEXT("ok") : TEXT("failed"), Baked ? Baked->GetNumTriangles(0) : -1);
	}

	Actor->Destroy();

	if (LevelPackage)
	{
		LevelPackage->SetDirtyFlag(bWasDirty);
	}
}

static FAutoConsoleCommand GSplineLoftSelfTestCommand(
	TEXT("SplineLoft.SelfTest"),
	TEXT("Sweeps every Spline Loft profile type and logs vertex/triangle counts and bounds."),
	FConsoleCommandDelegate::CreateStatic(&SplineLoftSelfTest));

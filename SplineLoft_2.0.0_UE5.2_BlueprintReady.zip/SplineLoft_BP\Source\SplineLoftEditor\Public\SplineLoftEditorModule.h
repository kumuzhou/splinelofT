#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"
#include "IPlacementModeModule.h"

class FSplineLoftEditorModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	TArray<TOptional<FPlacementModeID>> PlaceableItems;
	bool bCategoryRegistered = false;
};

#include "SplineLoftLibrary.h"

#include "Algo/Reverse.h"
#include "Components/SplineComponent.h"
#include "ProceduralMeshComponent.h"

namespace SplineLoftInternal
{
	struct FStation
	{
		FVector P = FVector::ZeroVector;	// position (target-mesh local space)
		FVector N = FVector::UpVector;		// ring plane normal (bisector at corners -> mitered joint)
		FVector M = FVector::ZeroVector;	// bend axis inside the ring plane (zero when straight)
		FVector Center = FVector::ZeroVector; // points from P toward the inside of the turn
		float Miter = 1.f;					// 1/cos(turn/2), clamped
		float Dist = 0.f;					// arc length from the spline start
		float MaxExtent = FLT_MAX;			// largest inner offset that does not fold this corner
		float Turn = 0.f;					// turn angle at this station (radians)
		float Radius = 0.f;					// local curvature radius (0 = straight)
		FVector Apex = FVector::ZeroVector;	// Trim: exact inner-offset self intersection to collapse onto
		float Collapse = 0.f;				// 0 = untouched, 1 = fully collapsed onto Apex
		float InnerSign = 0.f;				// +1 / -1: which way along M is the inside of the turn
		bool bFolded = false;				// inside a self-intersecting loop of the inner offset curve
		bool bCap = false;					// Cut mode: this ring ends a segment and needs a cap
		bool bCapReverse = false;			// Cut mode: cap facing the other way
	};

	/** One column of the loft (a profile vertex, possibly duplicated for a hard edge). */
	struct FProfileVert
	{
		FVector2D Pos = FVector2D::ZeroVector;
		FVector2D Nrm = FVector2D(1.f, 0.f);
		FVector2D Tan = FVector2D(0.f, 1.f);
		float Arc = 0.f;
	};

	/** Outward 2D normal of an edge for a CCW profile. */
	FORCEINLINE FVector2D EdgeNormal(const FVector2D& Dir)
	{
		return FVector2D(Dir.Y, -Dir.X);
	}

	/** Closest points between two 3D segments. Returns the squared distance. */
	static float ClosestSegmentSegment(const FVector& P1, const FVector& Q1, const FVector& P2, const FVector& Q2, FVector& OutC1, FVector& OutC2)
	{
		const FVector D1 = Q1 - P1;
		const FVector D2 = Q2 - P2;
		const FVector R = P1 - P2;

		const double A = D1 | D1;
		const double E = D2 | D2;
		const double F = D2 | R;

		double S = 0.0;
		double T = 0.0;

		if (A <= KINDA_SMALL_NUMBER && E <= KINDA_SMALL_NUMBER)
		{
			OutC1 = P1;
			OutC2 = P2;
			return (float)((P1 - P2).SizeSquared());
		}
		if (A <= KINDA_SMALL_NUMBER)
		{
			T = FMath::Clamp(F / E, 0.0, 1.0);
		}
		else
		{
			const double C = D1 | R;
			if (E <= KINDA_SMALL_NUMBER)
			{
				S = FMath::Clamp(-C / A, 0.0, 1.0);
			}
			else
			{
				const double B = D1 | D2;
				const double Denom = A * E - B * B;
				S = (Denom != 0.0) ? FMath::Clamp((B * F - C * E) / Denom, 0.0, 1.0) : 0.0;
				T = (B * S + F) / E;
				if (T < 0.0)
				{
					T = 0.0;
					S = FMath::Clamp(-C / A, 0.0, 1.0);
				}
				else if (T > 1.0)
				{
					T = 1.0;
					S = FMath::Clamp((B - C) / A, 0.0, 1.0);
				}
			}
		}

		OutC1 = P1 + D1 * S;
		OutC2 = P2 + D2 * T;
		return (float)((OutC1 - OutC2).SizeSquared());
	}
}

void USplineLoftLibrary::ClearLoftMesh(UProceduralMeshComponent* TargetMesh, int32 SectionIndex)
{
	if (!TargetMesh)
	{
		return;
	}
	if (SectionIndex < 0)
	{
		TargetMesh->ClearAllMeshSections();
	}
	else if (TargetMesh->GetNumSections() > SectionIndex)
	{
		TargetMesh->ClearMeshSection(SectionIndex);
	}
}

float USplineLoftLibrary::GetProfileLength(const TArray<FVector2D>& Profile, bool bClosed)
{
	if (Profile.Num() < 2)
	{
		return 0.f;
	}
	float Len = 0.f;
	for (int32 i = 1; i < Profile.Num(); ++i)
	{
		Len += (float)FVector2D::Distance(Profile[i - 1], Profile[i]);
	}
	if (bClosed)
	{
		Len += (float)FVector2D::Distance(Profile.Last(), Profile[0]);
	}
	return Len;
}

// ---------------------------------------------------------------------------------------------
// Profile presets
// ---------------------------------------------------------------------------------------------

TArray<FVector2D> USplineLoftLibrary::MakeCircleProfile(float Radius, int32 Segments)
{
	TArray<FVector2D> Out;
	const int32 N = FMath::Clamp(Segments, 3, 256);
	const float R = FMath::Max(Radius, 0.01f);
	Out.Reserve(N);
	for (int32 i = 0; i < N; ++i)
	{
		const float A = 2.f * PI * (float)i / (float)N;
		Out.Add(FVector2D(FMath::Cos(A), FMath::Sin(A)) * R);
	}
	return Out;
}

TArray<FVector2D> USplineLoftLibrary::MakeRectProfile(float Width, float Height, float Bevel, int32 BevelSegments)
{
	TArray<FVector2D> Out;

	const float HW = FMath::Max(Width, 0.02f) * 0.5f;
	const float HH = FMath::Max(Height, 0.02f) * 0.5f;
	const float R = FMath::Clamp(Bevel, 0.f, FMath::Min(HW, HH) - KINDA_SMALL_NUMBER);
	const int32 Seg = FMath::Clamp(BevelSegments, 1, 32);

	// Sharp box.
	if (R <= KINDA_SMALL_NUMBER)
	{
		Out.Add(FVector2D(HW, -HH));
		Out.Add(FVector2D(HW, HH));
		Out.Add(FVector2D(-HW, HH));
		Out.Add(FVector2D(-HW, -HH));
		return Out;
	}

	// Four rounded corners, CCW: bottom-right -> top-right -> top-left -> bottom-left.
	const FVector2D Centers[4] = {
		FVector2D(HW - R, -HH + R),
		FVector2D(HW - R, HH - R),
		FVector2D(-HW + R, HH - R),
		FVector2D(-HW + R, -HH + R)
	};
	const float StartDeg[4] = { -90.f, 0.f, 90.f, 180.f };

	Out.Reserve(4 * (Seg + 1));
	for (int32 C = 0; C < 4; ++C)
	{
		for (int32 S = 0; S <= Seg; ++S)
		{
			const float T = (float)S / (float)Seg;
			const float A = FMath::DegreesToRadians(StartDeg[C] + 90.f * T);
			Out.Add(Centers[C] + FVector2D(FMath::Cos(A), FMath::Sin(A)) * R);
		}
	}
	return Out;
}

TArray<FVector2D> USplineLoftLibrary::MakeArcProfile(float Radius, float Thickness, float StartAngleDeg, float EndAngleDeg, int32 Segments)
{
	TArray<FVector2D> Out;

	const int32 N = FMath::Clamp(Segments, 2, 256);
	const float R = FMath::Max(Radius, 0.01f);
	const float T = FMath::Max(Thickness, 0.f);
	const float A0 = FMath::DegreesToRadians(StartAngleDeg);
	const float A1 = FMath::DegreesToRadians(EndAngleDeg);
	const float ROut = R + T * 0.5f;
	const float RIn = FMath::Max(R - T * 0.5f, 0.005f);

	// Outer arc, start -> end.
	Out.Reserve(2 * (N + 1));
	for (int32 i = 0; i <= N; ++i)
	{
		const float A = FMath::Lerp(A0, A1, (float)i / (float)N);
		Out.Add(FVector2D(FMath::Cos(A), FMath::Sin(A)) * ROut);
	}

	if (T <= KINDA_SMALL_NUMBER)
	{
		return Out; // Open arc: use bClosedProfile = false.
	}

	// Inner arc, end -> start (closes the shell).
	for (int32 i = N; i >= 0; --i)
	{
		const float A = FMath::Lerp(A0, A1, (float)i / (float)N);
		Out.Add(FVector2D(FMath::Cos(A), FMath::Sin(A)) * RIn);
	}
	return Out;
}

// ---------------------------------------------------------------------------------------------
// Build
// ---------------------------------------------------------------------------------------------

bool USplineLoftLibrary::BuildLoftMesh(
	UProceduralMeshComponent* TargetMesh,
	USplineComponent* Spline,
	const TArray<FVector2D>& Profile,
	const FLoftOptions& Options,
	int32 SectionIndex)
{
	using namespace SplineLoftInternal;

	if (!TargetMesh || !Spline || Profile.Num() < 2)
	{
		return false;
	}

	const float SplineLen = Spline->GetSplineLength();
	float TotalPathLen = SplineLen;
	if (SplineLen <= KINDA_SMALL_NUMBER)
	{
		return false;
	}
	if (SectionIndex < 0)
	{
		SectionIndex = 0;
	}

	// ---------------------------------------------------------------- profile clean-up
	TArray<FVector2D> Prof;
	Prof.Reserve(Profile.Num());
	for (const FVector2D& V : Profile)
	{
		if (Prof.Num() == 0 || FVector2D::Distance(Prof.Last(), V) > KINDA_SMALL_NUMBER)
		{
			Prof.Add(V);
		}
	}
	if (Prof.Num() > 2 && FVector2D::Distance(Prof[0], Prof.Last()) <= KINDA_SMALL_NUMBER)
	{
		Prof.Pop();
	}
	if (Prof.Num() < 2)
	{
		return false;
	}

	const bool bClosedProfile = Options.bClosedProfile && Prof.Num() > 2;

	const ESplineLoftCornerMode CornerMode = Options.CornerMode;
	const float TrimFactor = FMath::Clamp(Options.TrimStrength, 0.05f, 1.f);

	// Make closed profiles CCW so that (dy, -dx) is the outward normal.
	if (bClosedProfile)
	{
		float Area2 = 0.f;
		for (int32 i = 0; i < Prof.Num(); ++i)
		{
			const FVector2D& A = Prof[i];
			const FVector2D& B = Prof[(i + 1) % Prof.Num()];
			Area2 += A.X * B.Y - B.X * A.Y;
		}
		if (Area2 < 0.f)
		{
			Algo::Reverse(Prof);
		}
	}

	if (!FMath::IsNearlyZero(Options.ProfileRotationDeg))
	{
		const float Rad = FMath::DegreesToRadians(Options.ProfileRotationDeg);
		const float C = FMath::Cos(Rad);
		const float S = FMath::Sin(Rad);
		for (FVector2D& V : Prof)
		{
			V = FVector2D(V.X * C - V.Y * S, V.X * S + V.Y * C);
		}
	}
	if (!Options.ProfileOffset.IsNearlyZero())
	{
		for (FVector2D& V : Prof)
		{
			V += Options.ProfileOffset;
		}
	}

	// ---------------------------------------------------------------- profile columns
	const int32 NumProfSrc = Prof.Num();
	const int32 NumEdges = bClosedProfile ? NumProfSrc : NumProfSrc - 1;

	TArray<float> ProfArc;
	ProfArc.Init(0.f, NumProfSrc);
	for (int32 j = 1; j < NumProfSrc; ++j)
	{
		ProfArc[j] = ProfArc[j - 1] + (float)FVector2D::Distance(Prof[j - 1], Prof[j]);
	}
	const float TotalArc = ProfArc.Last() + (bClosedProfile ? (float)FVector2D::Distance(Prof.Last(), Prof[0]) : 0.f);
	if (TotalArc <= KINDA_SMALL_NUMBER)
	{
		return false;
	}

	auto EdgeDir = [&Prof, NumProfSrc](int32 E) -> FVector2D
	{
		return (Prof[(E + 1) % NumProfSrc] - Prof[E % NumProfSrc]).GetSafeNormal();
	};

	TArray<FProfileVert> PV;
	PV.Reserve(NumProfSrc + 8);

	const float CosHard = FMath::Cos(FMath::DegreesToRadians(FMath::Clamp(Options.ProfileHardAngleDeg, 1.f, 89.f)));

	for (int32 j = 0; j < NumProfSrc; ++j)
	{
		const bool bHasPrev = bClosedProfile || j > 0;
		const bool bHasNext = bClosedProfile || j < NumProfSrc - 1;

		const FVector2D DPrev = bHasPrev ? EdgeDir((j - 1 + NumProfSrc) % NumProfSrc) : FVector2D::ZeroVector;
		const FVector2D DNext = bHasNext ? EdgeDir(j) : FVector2D::ZeroVector;
		const FVector2D NPrev = bHasPrev ? EdgeNormal(DPrev) : FVector2D::ZeroVector;
		const FVector2D NNext = bHasNext ? EdgeNormal(DNext) : FVector2D::ZeroVector;

		// Hard corner: emit the same position twice with the two edge normals.
		if (bHasPrev && bHasNext && (DPrev | DNext) < CosHard)
		{
			FProfileVert A;
			A.Pos = Prof[j];
			A.Nrm = NPrev;
			A.Tan = DPrev;
			A.Arc = ProfArc[j];
			PV.Add(A);

			FProfileVert B;
			B.Pos = Prof[j];
			B.Nrm = NNext;
			B.Tan = DNext;
			B.Arc = ProfArc[j];
			PV.Add(B);
		}
		else
		{
			FProfileVert V;
			V.Pos = Prof[j];
			V.Arc = ProfArc[j];
			const FVector2D N = NPrev + NNext;
			const FVector2D D = DPrev + DNext;
			V.Nrm = N.IsNearlyZero() ? (bHasNext ? NNext : NPrev) : N.GetSafeNormal();
			V.Tan = D.IsNearlyZero() ? (bHasNext ? DNext : DPrev) : D.GetSafeNormal();
			PV.Add(V);
		}
	}

	if (bClosedProfile)
	{
		FProfileVert Close = PV[0];
		Close.Arc = TotalArc;
		PV.Add(Close);
	}

	const int32 NumCols = PV.Num();
	if (NumCols < 2)
	{
		return false;
	}

	// Largest profile radius; also the probe length used to measure corner curvature.
	float ProfileExtent = 0.f;
	for (const FProfileVert& Column : PV)
	{
		ProfileExtent = FMath::Max(ProfileExtent, (float)Column.Pos.Size());
	}

	// ---------------------------------------------------------------- path stations
	const bool bClosedPath = Options.bClosedPath && Spline->IsClosedLoop();

	const FTransform ToLocal = TargetMesh->GetComponentTransform().Inverse();

	auto SamplePos = [&Spline, &ToLocal](float D) -> FVector
	{
		return ToLocal.TransformPosition(Spline->GetLocationAtDistanceAlongSpline(D, ESplineCoordinateSpace::World));
	};

	TArray<FVector> Pts;
	TArray<float> Dists;

	if (Options.bAdaptivePath)
	{
		// Chord-error subdivision: a straight run stops immediately (2 rings), curved parts keep
		// splitting until the deviation from the real curve is under PathTolerance.
		const float Tol = FMath::Max(Options.PathTolerance, 0.01f);
		const int32 MaxDepth = FMath::Clamp(Options.PathMaxDepth, 1, 12);

		Pts.Add(SamplePos(0.f));
		Dists.Add(0.f);

		// Max perpendicular deviation of three interior samples from the chord.
		// A single midpoint test is not enough: a symmetric S-curve puts its midpoint
		// exactly on the chord and would be mistaken for a straight line.
		TFunction<float(float, float)> ChordError = [&](float D0, float D1) -> float
		{
			const FVector P0 = SamplePos(D0);
			const FVector P1 = SamplePos(D1);
			const FVector Dir = P1 - P0;
			const float Len = (float)Dir.Size();
			if (Len < KINDA_SMALL_NUMBER)
			{
				return 0.f;
			}
			const FVector Unit = Dir / Len;

			float MaxErr = 0.f;
			for (int32 S = 1; S <= 3; ++S)
			{
				const FVector P = SamplePos(FMath::Lerp(D0, D1, (float)S / 4.f));
				const FVector V = P - P0;
				MaxErr = FMath::Max(MaxErr, (float)(V - Unit * (V | Unit)).Size());
			}
			return MaxErr;
		};

		TFunction<void(float, float, int32)> Subdivide = [&](float D0, float D1, int32 Depth)
		{
			const float Dm = 0.5f * (D0 + D1);
			if (Depth >= MaxDepth || (D1 - D0) <= 1e-3f || ChordError(D0, D1) <= Tol)
			{
				Pts.Add(SamplePos(D1));
				Dists.Add(D1);
				return;
			}
			Subdivide(D0, Dm, Depth + 1);
			Subdivide(Dm, D1, Depth + 1);
		};
		Subdivide(0.f, SplineLen, 0);

		if (bClosedPath && Pts.Num() > 1)
		{
			// Last sample equals the first one; the closed-loop duplicate ring is appended later.
			Pts.Pop();
			Dists.Pop();
		}
	}
	else
	{
		int32 NumSeg = FMath::Max(2, Options.PathSegments);
		if (Options.PathStep > KINDA_SMALL_NUMBER)
		{
			NumSeg = FMath::CeilToInt(SplineLen / Options.PathStep);
		}
		NumSeg = FMath::Clamp(NumSeg, 2, 4096);

		const int32 NumUniform = bClosedPath ? NumSeg : NumSeg + 1;
		Pts.Reserve(NumUniform);
		Dists.Reserve(NumUniform);

		for (int32 i = 0; i < NumUniform; ++i)
		{
			const float D = SplineLen * (float)i / (float)NumSeg;
			Pts.Add(SamplePos(D));
			Dists.Add(D);
		}
	}

	int32 NumSamples = Pts.Num();
	if (NumSamples < 2)
	{
		return false;
	}

	TArray<FStation> Stations;
	Stations.Reserve(NumSamples + 1);

	for (int32 i = 0; i < NumSamples; ++i)
	{
		FStation S;
		S.P = Pts[i];
		S.Dist = Dists[i];

		const int32 Prev = (i > 0) ? (i - 1) : (bClosedPath ? NumSamples - 1 : INDEX_NONE);
		const int32 Next = (i < NumSamples - 1) ? (i + 1) : (bClosedPath ? 0 : INDEX_NONE);

		FVector InDir = (Prev != INDEX_NONE) ? (Pts[i] - Pts[Prev]) : FVector::ZeroVector;
		FVector OutDir = (Next != INDEX_NONE) ? (Pts[Next] - Pts[i]) : FVector::ZeroVector;

		const float LenIn = (float)InDir.Size();
		const float LenOut = (float)OutDir.Size();

		if (!InDir.IsNearlyZero())
		{
			InDir.Normalize();
		}
		if (!OutDir.IsNearlyZero())
		{
			OutDir.Normalize();
		}

		if (InDir.IsNearlyZero() && OutDir.IsNearlyZero())
		{
			S.N = FVector::UpVector;
		}
		else if (InDir.IsNearlyZero())
		{
			S.N = OutDir;
		}
		else if (OutDir.IsNearlyZero())
		{
			S.N = InDir;
		}
		else
		{
			const FVector Sum = InDir + OutDir;
			if (Sum.SizeSquared() < 1e-6f)
			{
				// 180 degree reversal: no meaningful miter, fall back to the outgoing direction.
				S.N = OutDir;
			}
			else
			{
				S.N = Sum.GetSafeNormal();

				// Miter: scale the profile along the bend axis by 1 / cos(turn/2)
				// so the two neighbouring segments meet on a common planar ring.
				const float CosHalf = FMath::Sqrt(FMath::Max(0.f, 0.5f * (1.f + FMath::Clamp((float)(InDir | OutDir), -1.f, 1.f))));
				S.Miter = FMath::Clamp(1.f / FMath::Max(CosHalf, 1e-3f), 1.f, FMath::Max(1.f, Options.MiterLimit));

				FVector Bend = OutDir - InDir;
				Bend -= S.N * (Bend | S.N);
				S.M = Bend.GetSafeNormal();
			}
		}
		if (LenIn > KINDA_SMALL_NUMBER && LenOut > KINDA_SMALL_NUMBER)
		{
			S.Turn = FMath::Acos(FMath::Clamp((float)(InDir | OutDir), -1.f, 1.f));
		}

		// How far this corner may carry the profile before the inner offset folds through itself.
		// The probe is a fixed length relative to the profile, NOT the station spacing: adaptive
		// sampling gives neighbouring stations very different lengths, and a local estimate makes
		// the trim jump from ring to ring.
		if (ProfileExtent > KINDA_SMALL_NUMBER)
		{
			const float Probe = FMath::Max(ProfileExtent, 5.f);
			const float D0 = FMath::Max(0.f, S.Dist - Probe);
			const float D1 = FMath::Min(TotalPathLen, S.Dist + Probe);

			if (D1 - D0 > KINDA_SMALL_NUMBER)
			{
				const FVector A = SamplePos(D0);
				const FVector B = SamplePos(D1);
				const FVector VA = S.P - A;
				const FVector VB = B - S.P;
				const float LA = (float)VA.Size();
				const float LB = (float)VB.Size();

				if (LA > KINDA_SMALL_NUMBER && LB > KINDA_SMALL_NUMBER)
				{
					const float CosT = FMath::Clamp((float)((VA / LA) | (VB / LB)), -1.f, 1.f);
					const float Theta = FMath::Acos(CosT);
					if (Theta > 1e-3f)
					{
						float Radius = 0.5f * (LA + LB) / Theta;

						// A long probe over-estimates the radius of a sharp kink: both probe ends
						// point "up the legs" so the angle looks mild. The local station turn is
						// the honest sharpness measure there, so take the smaller of the two.
						if (LenIn > KINDA_SMALL_NUMBER && LenOut > KINDA_SMALL_NUMBER)
						{
							const float CosLocal = FMath::Clamp((float)(InDir | OutDir), -1.f, 1.f);
							const float ThetaLocal = FMath::Acos(CosLocal);
							if (ThetaLocal > 1e-4f)
							{
								Radius = FMath::Min(Radius, 0.5f * (LenIn + LenOut) / ThetaLocal);
							}
						}

						S.Radius = Radius;
						S.MaxExtent = TrimFactor * Radius;

						// Chord midpoint relative to P: points toward the inside of the turn.
						S.Center = 0.5f * (A + B) - S.P;
					}
				}
			}
		}

		if (!S.M.IsNearlyZero())
		{
			S.InnerSign = ((S.Center | S.M) > 0.f) ? 1.f : -1.f;
		}

Stations.Add(S);
	}

	if (bClosedPath)
	{
		FStation Dup = Stations[0];
		Dup.Dist = TotalPathLen;
		Stations.Add(Dup);
	}

	// --- Trim: remove the self intersecting loops of the INNER offset curve ------------
	// This is the standard offset-curve trim: walk the inner boundary, find where two
	// non-adjacent segments cross, and collapse everything between them onto that point.
	// The apex is an exact geometric intersection, not an estimate, so the fan sits
	// exactly where the two sides meet.
	if (CornerMode == ESplineLoftCornerMode::Trim && Stations.Num() >= 4 && ProfileExtent > KINDA_SMALL_NUMBER)
	{
		const int32 NumStations = Stations.Num();

		TArray<FVector> Inner;
		Inner.SetNumUninitialized(NumStations);

		for (int32 i = 0; i < NumStations; ++i)
		{
			const FStation& St = Stations[i];
			if (St.M.IsNearlyZero() || St.Center.IsNearlyZero())
			{
				Inner[i] = St.P;
				continue;
			}
			const float Sign = ((St.Center | St.M) > 0.f) ? 1.f : -1.f;
			Inner[i] = St.P + St.M * (Sign * ProfileExtent * St.Miter);
		}

		const float Tolerance = (Options.TrimTolerance > KINDA_SMALL_NUMBER)
			? Options.TrimTolerance
			: FMath::Max(0.01f, 0.02f * ProfileExtent);

		for (int32 A = 0; A + 3 < NumStations; ++A)
		{
			// Skip segments that were already consumed by an earlier loop.
			if (Stations[A + 1].Collapse > 0.f)
			{
				continue;
			}

			for (int32 C = A + 2; C + 1 < NumStations; ++C)
			{
				FVector ClosestA;
				FVector ClosestC;
				const float DistSq = ClosestSegmentSegment(Inner[A], Inner[A + 1], Inner[C], Inner[C + 1], ClosestA, ClosestC);
				if (DistSq > Tolerance * Tolerance)
				{
					continue;
				}

				const FVector Apex = 0.5f * (ClosestA + ClosestC);
				for (int32 K = A + 1; K <= C; ++K)
				{
					Stations[K].Collapse = 1.f;
					Stations[K].Apex = Apex;
				}
				break;
			}
		}
	}


	// ---------------------------------------------------------------- rotation minimising frames
	TArray<FVector> Rights;
	TArray<FVector> Ups;
	Rights.Reserve(Stations.Num());
	Ups.Reserve(Stations.Num());

	FVector InitUp = ToLocal.TransformVectorNoScale(Spline->GetUpVectorAtDistanceAlongSpline(0.f, ESplineCoordinateSpace::World)).GetSafeNormal();
	if (InitUp.IsNearlyZero())
	{
		InitUp = FVector::UpVector;
	}

	{
		const FVector N0 = Stations[0].N;
		FVector U0 = InitUp - N0 * (InitUp | N0);
		if (U0.IsNearlyZero())
		{
			const FVector Alt = (FMath::Abs(N0.Z) < 0.9f) ? FVector::UpVector : FVector::ForwardVector;
			U0 = Alt - N0 * (Alt | N0);
		}
		U0.Normalize();

		// Right-handed frame: Right x Up = Normal.
		Rights.Add(FVector::CrossProduct(U0, N0).GetSafeNormal());
		Ups.Add(U0);
	}

	for (int32 i = 1; i < Stations.Num(); ++i)
	{
		const FVector PrevT = Stations[i - 1].N;
		const FVector CurT = Stations[i].N;
		FVector R = Rights[i - 1];

		const FVector V1 = Stations[i].P - Stations[i - 1].P;
		const float C1 = (float)V1.SizeSquared();
		if (C1 > 1e-8f)
		{
			const FVector RL = R - (2.f / C1) * (V1 | R) * V1;
			const FVector TL = PrevT - (2.f / C1) * (V1 | PrevT) * V1;
			const FVector V2 = CurT - TL;
			const float C2 = (float)V2.SizeSquared();
			R = (C2 > 1e-8f) ? (RL - (2.f / C2) * (V2 | RL) * V2) : RL;
		}

		R -= CurT * (R | CurT);
		if (!R.Normalize())
		{
			R = Rights[i - 1];
		}

		Rights.Add(R);
		Ups.Add(FVector::CrossProduct(CurT, R).GetSafeNormal());
	}

	// Closed loop: distribute the holonomy so the last ring matches the first one exactly.
	if (bClosedPath && Stations.Num() >= 3)
	{
		const int32 Last = Stations.Num() - 1;
		const FVector NEnd = Stations[Last].N;
		const FVector REnd = Rights[Last];
		const FVector RStart = Rights[0];

		const float Dot = FMath::Clamp((float)(REnd | RStart), -1.f, 1.f);
		const float Sin = (float)((REnd ^ RStart) | NEnd);
		const float Ang = FMath::Atan2(Sin, Dot);

		if (FMath::Abs(Ang) > KINDA_SMALL_NUMBER)
		{
			for (int32 i = 0; i <= Last; ++i)
			{
				const float A = Ang * (float)i / (float)Last;
				const FQuat Q(Stations[i].N, A);
				Rights[i] = Q.RotateVector(Rights[i]);
				Ups[i] = Q.RotateVector(Ups[i]);
			}
		}
		Rights[Last] = RStart;
		Ups[Last] = Ups[0];
	}

	// ---------------------------------------------------------------- vertices
	const float TileU = FMath::Max(Options.TileU, KINDA_SMALL_NUMBER);
	const float TileV = FMath::Max(Options.TileV, KINDA_SMALL_NUMBER);

	TArray<FVector> Positions;
	TArray<FVector> Verts;
	TArray<FVector> Normals;
	TArray<FVector2D> UV0;
	TArray<FVector2D> UV1;
	TArray<FProcMeshTangent> Tangents;
	TArray<int32> Tris;

	const int32 VertCount = Stations.Num() * NumCols;
	Verts.Reserve(VertCount);
	Normals.Reserve(VertCount);
	UV0.Reserve(VertCount);
	UV1.Reserve(VertCount);
	Tangents.Reserve(VertCount);
	Tris.Reserve((Stations.Num() - 1) * (NumCols - 1) * 6);

	for (int32 i = 0; i < Stations.Num(); ++i)
	{
		const FStation& S = Stations[i];
		const FVector& Right = Rights[i];
		const FVector& Up = Ups[i];

		const bool bHasLimit = (S.MaxExtent < FLT_MAX) && !S.M.IsNearlyZero();

		// Which side of the ring is the inside of the turn (the side that would fold).
		float InnerSign = 0.f;
		if (bHasLimit)
		{
			const float CR = (float)(S.Center | Right);
			const float CU = (float)(S.Center | Up);
			const float MR = (float)(S.M | Right);
			const float MU = (float)(S.M | Up);
			const float Dot = CR * MR + CU * MU;
			InnerSign = (Dot > 0.f) ? 1.f : ((Dot < 0.f) ? -1.f : 0.f);
		}

		for (int32 k = 0; k < NumCols; ++k)
		{
			const FProfileVert& P = PV[k];
			FVector Offset = (Right * P.Pos.X + Up * P.Pos.Y);
			if (S.Miter > 1.f && !S.M.IsNearlyZero())
			{
				Offset += S.M * (S.M | Offset) * (S.Miter - 1.f);
			}
			Positions.Add(S.P + Offset);
		}
	}

	// --- Trim: per column self intersection removal ------------------------------------
	// Every profile vertex rides its own offset curve, so the top and bottom edge of a wall
	// each get their own intersection point. Collapsing a whole ring onto one apex is what
	// used to squash the cross section at sharp corners.
	if (CornerMode == ESplineLoftCornerMode::Trim && Stations.Num() >= 4 && NumCols > 1)
	{
		const int32 NumStations = Stations.Num();
		const float Tol = (Options.TrimTolerance > KINDA_SMALL_NUMBER)
			? Options.TrimTolerance
			: FMath::Max(0.01f, 0.02f * ProfileExtent);

		for (int32 k = 0; k < NumCols; ++k)
		{
			for (int32 A = 0; A + 3 < NumStations; ++A)
			{
				const FVector A0 = Positions[A * NumCols + k];
				const FVector A1 = Positions[(A + 1) * NumCols + k];
				if ((A1 - A0).IsNearlyZero())
				{
					continue;
				}
				for (int32 C = A + 2; C + 1 < NumStations; ++C)
				{
					FVector ClosestA;
					FVector ClosestC;
					const float DistSq = ClosestSegmentSegment(A0, A1, Positions[C * NumCols + k], Positions[(C + 1) * NumCols + k], ClosestA, ClosestC);
					if (DistSq > Tol * Tol)
					{
						continue;
					}
					const FVector VertexApex = 0.5f * (ClosestA + ClosestC);
					for (int32 K = A + 1; K <= C; ++K)
					{
						Positions[K * NumCols + k] = VertexApex;
					}
					A = C;
					break;
				}
			}
		}
	}

	for (int32 i = 0; i < Stations.Num(); ++i)
	{
		const FStation& S = Stations[i];
		const FVector& Right = Rights[i];
		const FVector& Up = Ups[i];

		for (int32 k = 0; k < NumCols; ++k)
		{
			const FProfileVert& P = PV[k];

			FVector N3 = (Right * P.Nrm.X + Up * P.Nrm.Y).GetSafeNormal();
			if (Options.bFlipNormals)
			{
				N3 = -N3;
			}

			Verts.Add(Positions[i * NumCols + k]);
			Normals.Add(N3);
			Tangents.Add(FProcMeshTangent((Right * P.Tan.X + Up * P.Tan.Y).GetSafeNormal(), false));

			const float U = Options.bNormalizeU ? (P.Arc / TotalArc) : (P.Arc / TileU);
			const float V = Options.bNormalizeV ? (S.Dist / TotalPathLen) : (S.Dist / TileV);

			UV0.Add(FVector2D(U, V));
			UV1.Add(FVector2D(P.Arc / TotalArc, S.Dist / TotalPathLen));
		}
	}

	// ---------------------------------------------------------------- triangles
	// UE treats clockwise (in screen space) as the front face, which is the reverse of the
	// right-handed (profile x path) order used above. So emit reversed by default.
	auto AddTri = [&Tris, &Options](int32 A, int32 B, int32 C)
	{
		if (Options.bFlipWinding)
		{
			Tris.Add(A);
			Tris.Add(B);
			Tris.Add(C);
		}
		else
		{
			Tris.Add(A);
			Tris.Add(C);
			Tris.Add(B);
		}
	};

	for (int32 i = 0; i + 1 < Stations.Num(); ++i)
	{
		for (int32 k = 0; k + 1 < NumCols; ++k)
		{
			// Skip the zero-width seam between the two halves of a split hard corner.
			if (FVector2D::Distance(PV[k].Pos, PV[k + 1].Pos) <= KINDA_SMALL_NUMBER)
			{
				continue;
			}

			const int32 I0 = i * NumCols + k;
			const int32 I1 = I0 + 1;
			const int32 I2 = I0 + NumCols;
			const int32 I3 = I2 + 1;

			AddTri(I0, I1, I3);
			AddTri(I0, I3, I2);
		}
	}


	if (Tris.Num() == 0)
	{
		return false;
	}

	TargetMesh->CreateMeshSection_LinearColor(
		SectionIndex,
		Verts,
		Tris,
		Normals,
		UV0,
		UV1,
		TArray<FVector2D>(),
		TArray<FVector2D>(),
		TArray<FLinearColor>(),
		Tangents,
		Options.bCreateCollision);

	return true;
}


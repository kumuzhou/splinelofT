// Spline loft / bevel-profile sweep for Unreal Engine 5.2
// Sweeps a closed or open 2D profile along a USplineComponent into ONE continuous
// procedural mesh section: shared rings (mitered joints), arc-length UVs, analytic normals.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "SplineLoftLibrary.generated.h"

class UProceduralMeshComponent;
class USplineComponent;

/** What to do when the profile is wider than the turn, i.e. when the inner offset would fold. */
UENUM(BlueprintType)
enum class ESplineLoftCornerMode : uint8
{
	/** Pure miter. Keeps full width, but the inner side folds through itself on tight turns. */
	Miter	UMETA(DisplayName = "Miter (sharp, may self-intersect)"),
	/** Clamp the profile along the bend axis. No crossing faces; tight corners go flat/beveled. */
	Trim	UMETA(DisplayName = "Trim (no crossing, keeps width)")

};

/** All knobs for one loft. Units are centimetres / degrees. */
USTRUCT(BlueprintType)
struct SPLINELOFT_API FLoftOptions
{
	GENERATED_BODY()

	// ---------------- Path ----------------

	/** Connect the last ring back to the first. Only honoured when the spline component itself is a closed loop. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path")
	bool bClosedPath = false;

	/** Number of path segments. Ignored when PathStep > 0 or when adaptive sampling is on. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "2", ClampMax = "4096"))
	int32 PathSegments = 64;

	/** If > 0, resample the path every PathStep cm (uniform rings, constant V density). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "0.0"))
	float PathStep = 0.f;

	/**
	 * Curvature adaptive sampling: a straight run collapses to a couple of rings and only the
	 * curved parts get subdivided, down to PathTolerance cm of chord error.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path")
	bool bAdaptivePath = true;

	/** Max deviation (cm) between the real curve and the straight segment used for it. Smaller = more rings. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "0.01"))
	float PathTolerance = 0.5f;

	/** Recursion depth cap for adaptive sampling (2^depth rings max). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "1", ClampMax = "12"))
	int32 PathMaxDepth = 8;

	/** Clamp for the miter stretch. 1.0 = no mitering (rings stay perpendicular to the segment), higher = sharper corners allowed. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "1.0", ClampMax = "64.0"))
	float MiterLimit = 4.f;

	/**
	 * How to keep the surface from folding through itself where a corner is tighter than the profile.
	 * Only matters when (profile half width * miter) exceeds the local curvature radius.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path")
	ESplineLoftCornerMode CornerMode = ESplineLoftCornerMode::Trim;

	/** Trim mode: tolerance (cm) for treating two inner-offset segments as intersecting. 0 = auto (2% of the profile). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "0.0"))
	float TrimTolerance = 0.f;

	/**
	 * Miter mode: delete the faces caught inside the fold where the inner offset curve crosses
	 * itself. The outer silhouette is untouched (the corner keeps its mitered shape), but
	 * translucent materials no longer double up there.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path")
	bool bRemoveFoldedFaces = false;

	/** How much of the curvature radius the trim keeps. Lower = the inner corner is cut deeper (0.3 ~ 0.7 is the useful range). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "0.05", ClampMax = "1.0"))
	float TrimStrength = 0.5f;

	/** Floor for CornerMode = Shrink (fraction of the profile). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Path", meta = (ClampMin = "0.05", ClampMax = "1.0"))
	float MinWidthScale = 0.15f;

	// ---------------- Profile ----------------

	/** Closed profile = tube. Open profile = ribbon (needs a two-sided material). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Profile")
	bool bClosedProfile = true;

	/** Profile corners sharper than this get split normals (hard edge). 60-89 keeps bevels smooth. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Profile", meta = (ClampMin = "1.0", ClampMax = "89.0"))
	float ProfileHardAngleDeg = 60.f;

	/** Rotate the profile around the path (CCW). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Profile")
	float ProfileRotationDeg = 0.f;

	/** Shift the profile relative to the path. X = spline right, Y = spline up. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Profile")
	FVector2D ProfileOffset = FVector2D::ZeroVector;

	// ---------------- UV ----------------

	/** Map U to 0..1 across the whole profile (one texture around it, no tiling). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|UV")
	bool bNormalizeU = true;

	/** Map V to 0..1 across the whole spline (one texture along it, no tiling). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|UV")
	bool bNormalizeV = true;

	/** World length (cm) that one U tile covers when bNormalizeU is off. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|UV", meta = (ClampMin = "0.01"))
	float TileU = 100.f;

	/** World length (cm) that one V tile covers when bNormalizeV is off. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|UV", meta = (ClampMin = "0.01"))
	float TileV = 100.f;

	// ---------------- Mesh ----------------

	/** Flip triangle winding if the result renders inside-out. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Mesh")
	bool bFlipWinding = false;

	/** Flip normals (does not affect winding). */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Mesh")
	bool bFlipNormals = false;

	/** Collision from a procedural mesh is expensive - off for VFX. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Loft|Mesh")
	bool bCreateCollision = false;
};

UCLASS()
class SPLINELOFT_API USplineLoftLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/**
	 * Rebuild TargetMesh Section SectionIndex from Spline + Profile.
	 * Profile is a 2D polyline in the spline's frame: X = right, Y = up.
	 * Closed profiles are auto-corrected to CCW.
	 */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft", meta = (AdvancedDisplay = "SectionIndex"))
	static bool BuildLoftMesh(
		UProceduralMeshComponent* TargetMesh,
		USplineComponent* Spline,
		const TArray<FVector2D>& Profile,
		const FLoftOptions& Options,
		int32 SectionIndex = 0);

	/** Remove one section (SectionIndex < 0 clears all). */
	UFUNCTION(BlueprintCallable, Category = "Spline Loft")
	static void ClearLoftMesh(UProceduralMeshComponent* TargetMesh, int32 SectionIndex = 0);

	/** Convenience: total length of a profile polyline (use it as TileU for a single texture wrap). */
	UFUNCTION(BlueprintPure, Category = "Spline Loft|Profile")
	static float GetProfileLength(const TArray<FVector2D>& Profile, bool bClosed);

	// ---------------- Profile presets ----------------

	/** Circle of radius Radius, CCW, Segments points. */
	UFUNCTION(BlueprintPure, Category = "Spline Loft|Profile")
	static TArray<FVector2D> MakeCircleProfile(float Radius, int32 Segments);

	/**
	 * Rectangle Width x Height with rounded corners.
	 * Bevel = 0 -> sharp box (4 points). BevelSegments = 1 -> chamfer, >= 2 -> round bevel.
	 */
	UFUNCTION(BlueprintPure, Category = "Spline Loft|Profile")
	static TArray<FVector2D> MakeRectProfile(float Width, float Height, float Bevel, int32 BevelSegments);

	/**
	 * Arc / half-pipe. Thickness <= 0 -> open arc (set bClosedProfile = false).
	 * Thickness > 0 -> closed shell between Radius +/- Thickness/2.
	 */
	UFUNCTION(BlueprintPure, Category = "Spline Loft|Profile")
	static TArray<FVector2D> MakeArcProfile(float Radius, float Thickness, float StartAngleDeg, float EndAngleDeg, int32 Segments);
};

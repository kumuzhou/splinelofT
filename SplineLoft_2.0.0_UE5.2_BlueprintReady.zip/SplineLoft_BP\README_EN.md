# Spline Loft - Bevel Profile

Sweep a 2D cross-section along any spline into **one continuous mesh** — the Unreal Engine
equivalent of 3ds Max's *Bevel Profile*. Built for UE 5.2+.

- Placeable actor with live editor rebuild
- Miter and Trim corner handling
- Arc-length UVs that do not stretch when the path gets longer
- Hard / soft profile edges resolved automatically
- One-click bake to a StaticMesh asset (optionally spawning a matching actor)
- Bilingual details panel (English / Chinese, follows the editor language)

---

## Requirements

| | |
|---|---|
| Engine | Unreal Engine **5.2** or newer |
| Plugin dependency | `ProceduralMeshComponent` (enabled automatically) |
| Platforms | Win64, other desktop platforms buildable from source |

## Installation

1. Copy the `SplineLoft` folder into `<YourProject>/Plugins/`
2. Restart the editor and enable **Spline Loft** in *Edit → Plugins*
3. Find it in **Place Actors → Spline Loft**

## Prebuilt binaries

This package includes prebuilt Win64 editor binaries for **UE 5.2**, so a Blueprint-only
project can load the plugin without a compiler. If your engine build differs, Unreal asks
once to rebuild the modules - click **Yes** (requires Visual Studio 2022 with the C++
workload).

## Quick start

1. Drag **Spline Loft** into the level.
2. Select the actor and move the spline points in the viewport.
3. The mesh rebuilds live while the actor is selected.
4. Pick a **Profile Type** (`Pipe`, `Box`, `Ribbon`, `Half Pipe`, `Custom`) and tune the size.

## Parameters

### Profile
| Parameter | Meaning |
|---|---|
| Profile Type | Cross-section shape: Pipe / Box / Ribbon / Half Pipe / Custom |
| Radius | Radius for Pipe and Half Pipe |
| Radial Segments | Segments around the cross-section (24 is a good default) |
| Width / Height | Size along the spline's right / up axis |
| Bevel Radius / Bevel Segments | Box corner rounding. 1 segment = chamfer, 2+ = round |
| Half Pipe Thickness | Wall thickness of the half pipe |
| Custom Profile Points | 2D outline used by `Custom` (X = right, Y = up, centimetres) |
| Profile Scale / Rotation / Offset | Whole-profile transform |
| Profile Hard Angle | Edges sharper than this stay hard, flatter ones are smoothed (60° default) |

### Path
| Parameter | Meaning |
|---|---|
| Adaptive Segments | Straight runs stay coarse, curves are subdivided automatically |
| Curve Tolerance | Maximum chord error in cm. Lower = more rings = smoother bends |
| Path Step | Ring spacing when adaptive sampling is off |
| Miter Limit | Clamp for the miter stretch. A 90° corner needs at least 1.414 |
| Corner Mode | `Miter` or `Trim` (see below) |

### UV
| Parameter | Meaning |
|---|---|
| UV Mode | `Normalized` = one 0-1 UV set for the whole mesh, `World Tiling` = repeat by length |
| Tile U / Tile V | Texture size in cm for world tiling |

### Mesh
| Parameter | Meaning |
|---|---|
| Material | Applied to the generated section |
| Create Collision | Procedural collision is expensive, leave it off for effects |
| Flip Winding / Flip Normals | Fix an inside-out surface |
| Create Static Mesh | Bake into a StaticMesh asset |
| Create + Actor | Bake and spawn a StaticMeshActor with the same name at the same transform |

## Corner modes

Bending a tube tighter than its own half-width is geometrically impossible without one of
three compromises. Pick per project:

**Miter** — keeps the full width and gives the sharp, architectural corner. On tight turns
the inner wall folds through itself; with an opaque material this is invisible.

**Trim** — cuts the inner side and collapses it onto the exact self-intersection point,
producing the fan topology 3ds Max uses. Best for flat strips (`Ribbon`), where it is clean.
On a closed box it pinches the inner wall into a line.

Rules of thumb:

- Opaque tube or box → **Miter**
- Flat strip / ribbon → **Trim**
- Very sharp hairpin on a thick box → no sweep can stay clean; widen the spline radius or
  lower **Miter Limit** to shrink the folded area

## UVs

`U` follows the profile arc length, `V` follows the path arc length, both in centimetres.
Tessellation changes never change the UVs, so textures do not swim when you add segments.
`Normalized` maps the whole mesh into 0-1; `World Tiling` repeats every *Tile U/V* cm.

## Baking to a static mesh

The two buttons live in **4 Mesh**:

| Button | Result |
|---|---|
| **Create Static Mesh** | Saves a StaticMesh asset, nothing is added to the level |
| **Create + Actor** | Saves the asset **and** spawns a `StaticMeshActor` with the same name at the same transform |

Both open the standard asset save dialog (path + name). Console alternative:

```
SplineLoft.Bake
```

Source actors are never modified.

## Troubleshooting

**Dark patches at tight corners** — the miter fold overlaps itself. Lower **Miter Limit**,
increase the corner radius in the spline, or switch to `Trim` for flat strips.

**Bends look faceted** — lower **Curve Tolerance** (0.5 → 0.2). The faceting comes from
tessellation, not from missing smoothing.

**Cross-section looks polygonal** — raise **Radial Segments** (24 → 32/48) or
**Bevel Segments**.

**Mesh is inside out** — enable *Flip Winding* in **4 Mesh**.

**Nothing rebuilds while editing** — the actor only rebuilds while it is selected.

## Support

Include your engine version and a screenshot of the actor's Details panel when reporting an
issue. The plugin logs under the `LogSplineLoft` category.

---

*Chinese documentation: [README.md](README.md)*

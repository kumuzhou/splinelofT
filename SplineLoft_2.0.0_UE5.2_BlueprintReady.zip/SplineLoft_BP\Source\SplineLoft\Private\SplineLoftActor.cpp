#include "SplineLoftActor.h"

#include "Components/SplineComponent.h"
#include "ProceduralMeshComponent.h"
#include "Materials/MaterialInterface.h"
#include "Engine/World.h"

namespace
{
	FORCEINLINE uint32 HashVector(uint32 Seed, const FVector& V)
	{
		Seed = HashCombine(Seed, GetTypeHash(V.X));
		Seed = HashCombine(Seed, GetTypeHash(V.Y));
		return HashCombine(Seed, GetTypeHash(V.Z));
	}
}

ASplineLoftActor::ASplineLoftActor()
{
	// Tick only exists to rebuild while editing; shipped builds get no tick cost.
#if WITH_EDITOR
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
#else
	PrimaryActorTick.bCanEverTick = false;
#endif

	Spline = CreateDefaultSubobject<USplineComponent>(TEXT("Spline"));
	RootComponent = Spline;

	// A small default path so the actor is not empty when dropped in the level.
	TArray<FVector> DefaultPoints;
	DefaultPoints.Add(FVector(0.f, 0.f, 0.f));
	DefaultPoints.Add(FVector(300.f, 0.f, 0.f));
	DefaultPoints.Add(FVector(600.f, 300.f, 0.f));
	DefaultPoints.Add(FVector(900.f, 300.f, 0.f));
	Spline->SetSplinePoints(DefaultPoints, ESplineCoordinateSpace::Local, false);
	Spline->SetClosedLoop(false, false);
	Spline->UpdateSpline();

	LoftMesh = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("LoftMesh"));
	LoftMesh->SetupAttachment(Spline);
	LoftMesh->bUseAsyncCooking = false;
	LoftMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	LoftMesh->SetCastShadow(false);

	// A visible default so switching Profile Type to Custom shows something right away.
	CustomProfile.Reset();
	CustomProfile.Add(FVector2D(-50.f, -50.f));
	CustomProfile.Add(FVector2D(50.f, -50.f));
	CustomProfile.Add(FVector2D(50.f, 50.f));
	CustomProfile.Add(FVector2D(-50.f, 50.f));
}

// ------------------------------------------------------------------------------------------------

void ASplineLoftActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	RebuildLoft();
}

void ASplineLoftActor::BeginPlay()
{
	Super::BeginPlay();

	if (LoftMesh && LoftMesh->GetNumSections() == 0)
	{
		RebuildLoft();
	}
}

void ASplineLoftActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

#if WITH_EDITOR
	// Live update while the spline is being edited. Cheap: one hash per frame,
	// and only for the actor that is actually selected.
	if (Spline && LoftMesh && IsSelected() && GetWorld() && GetWorld()->WorldType == EWorldType::Editor)
	{
		const uint32 Hash = ComputeSettingsHash();
		if (Hash != LastHash)
		{
			RebuildLoft();
		}
	}
#endif
}

#if WITH_EDITOR
void ASplineLoftActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);
	RebuildLoft();
}

void ASplineLoftActor::PostEditChangeChainProperty(FPropertyChangedChainEvent& PropertyChangedEvent)
{
	Super::PostEditChangeChainProperty(PropertyChangedEvent);
	RebuildLoft();
}
#endif

// ------------------------------------------------------------------------------------------------

uint32 ASplineLoftActor::ComputeSettingsHash() const
{
	if (!Spline)
	{
		return 0;
	}

	uint32 H = 17;
	H = HashCombine(H, GetTypeHash((int32)ProfileType));
	H = HashCombine(H, GetTypeHash(Radius));
	H = HashCombine(H, GetTypeHash(ProfileScale));
	H = HashCombine(H, GetTypeHash(RadialSegments));
	H = HashCombine(H, GetTypeHash(Width));
	H = HashCombine(H, GetTypeHash(Height));
	H = HashCombine(H, GetTypeHash(BevelRadius));
	H = HashCombine(H, GetTypeHash(BevelSegments));
	H = HashCombine(H, GetTypeHash(Thickness));
	H = HashCombine(H, GetTypeHash(ArcStartAngle));
	H = HashCombine(H, GetTypeHash(ArcEndAngle));
	H = HashCombine(H, GetTypeHash(bClosedCustomProfile));
	H = HashCombine(H, GetTypeHash(ProfileRotation));
	H = HashCombine(H, GetTypeHash(ProfileOffset.X));
	H = HashCombine(H, GetTypeHash(ProfileOffset.Y));
	H = HashCombine(H, GetTypeHash(PathStep));
	H = HashCombine(H, GetTypeHash(MiterLimit));
	H = HashCombine(H, GetTypeHash(bAdaptivePath));
	H = HashCombine(H, GetTypeHash(PathTolerance));
	H = HashCombine(H, GetTypeHash((int32)CornerMode));
	H = HashCombine(H, GetTypeHash(TrimTolerance));
	H = HashCombine(H, GetTypeHash((int32)UVMode));
	H = HashCombine(H, GetTypeHash(TileU));
	H = HashCombine(H, GetTypeHash(TileV));
	H = HashCombine(H, GetTypeHash(bFlipWinding));
	H = HashCombine(H, GetTypeHash(bFlipNormals));
	H = HashCombine(H, GetTypeHash(bCreateCollision));
	H = HashCombine(H, GetTypeHash(CustomProfile.Num()));
	for (const FVector2D& P : CustomProfile)
	{
		H = HashCombine(H, GetTypeHash(P.X));
		H = HashCombine(H, GetTypeHash(P.Y));
	}

	// Spline state.
	H = HashCombine(H, GetTypeHash(Spline->IsClosedLoop()));
	const int32 NumPoints = Spline->GetNumberOfSplinePoints();
	H = HashCombine(H, GetTypeHash(NumPoints));
	for (int32 i = 0; i < NumPoints; ++i)
	{
		H = HashVector(H, Spline->GetLocationAtSplinePoint(i, ESplineCoordinateSpace::Local));
	}
	H = HashCombine(H, GetTypeHash((float)Spline->GetSplineLength()));

	return H;
}

// ------------------------------------------------------------------------------------------------

TArray<FVector2D> ASplineLoftActor::GetProfilePoints() const
{
	TArray<FVector2D> Points = BuildRawProfilePoints();

	const float Scale = FMath::Max(ProfileScale, 0.01f);
	if (!FMath::IsNearlyEqual(Scale, 1.f))
	{
		for (FVector2D& P : Points)
		{
			P *= Scale;
		}
	}
	return Points;
}

TArray<FVector2D> ASplineLoftActor::BuildRawProfilePoints() const
{
	switch (ProfileType)
	{
	case ESplineLoftProfileType::Pipe:
		return USplineLoftLibrary::MakeCircleProfile(Radius, RadialSegments);

	case ESplineLoftProfileType::Box:
		return USplineLoftLibrary::MakeRectProfile(Width, Height, BevelRadius, BevelSegments);

	case ESplineLoftProfileType::HalfPipe:
		return USplineLoftLibrary::MakeArcProfile(Radius, Thickness, ArcStartAngle, ArcEndAngle, RadialSegments);

	case ESplineLoftProfileType::Ribbon:
	{
		// Ordered right -> left so the front side (normal) points UP.
		TArray<FVector2D> P;
		P.Add(FVector2D(Width * 0.5f, 0.f));
		P.Add(FVector2D(-Width * 0.5f, 0.f));
		return P;
	}

	case ESplineLoftProfileType::RibbonVertical:
	{
		// Ordered bottom -> top so the front side (normal) points to the spline's right.
		TArray<FVector2D> P;
		P.Add(FVector2D(0.f, -Height * 0.5f));
		P.Add(FVector2D(0.f, Height * 0.5f));
		return P;
	}

	case ESplineLoftProfileType::Custom:
	default:
		return CustomProfile;
	}
}

bool ASplineLoftActor::IsProfileClosed() const
{
	switch (ProfileType)
	{
	case ESplineLoftProfileType::Pipe:
	case ESplineLoftProfileType::Box:
		return true;

	case ESplineLoftProfileType::HalfPipe:
		return Thickness > KINDA_SMALL_NUMBER;

	case ESplineLoftProfileType::Ribbon:
	case ESplineLoftProfileType::RibbonVertical:
		return false;

	case ESplineLoftProfileType::Custom:
	default:
		return bClosedCustomProfile;
	}
}

void ASplineLoftActor::RebuildLoft()
{
	if (!Spline || !LoftMesh)
	{
		return;
	}

	const TArray<FVector2D> Profile = GetProfilePoints();
	const bool bClosedProfile = IsProfileClosed();

	FLoftOptions Options;
	Options.bClosedPath = Spline->IsClosedLoop();
	Options.bAdaptivePath = bAdaptivePath;
	Options.PathTolerance = FMath::Max(PathTolerance, 0.01f);
	Options.PathStep = FMath::Max(PathStep, 1.f);
	Options.MiterLimit = FMath::Max(MiterLimit, 1.f);
	Options.CornerMode = CornerMode;
	Options.TrimTolerance = FMath::Max(TrimTolerance, 0.f);
	Options.bClosedProfile = bClosedProfile;
	Options.ProfileRotationDeg = ProfileRotation;
	Options.ProfileOffset = ProfileOffset;
	Options.TileV = FMath::Max(TileV, 0.01f);
	Options.bFlipWinding = bFlipWinding;
	Options.bFlipNormals = bFlipNormals;
	Options.bCreateCollision = bCreateCollision;

	// Normalized: the whole model is one 0..1 UV. World Tiling: repeat by length.
	const bool bNormalized = (UVMode == ESplineLoftUVMode::Normalized);
	Options.bNormalizeU = bNormalized;
	Options.bNormalizeV = bNormalized;
	Options.TileU = FMath::Max(TileU, 0.01f);

	const bool bOk = USplineLoftLibrary::BuildLoftMesh(LoftMesh, Spline, Profile, Options, 0);
	if (!bOk)
	{
		USplineLoftLibrary::ClearLoftMesh(LoftMesh, 0);
	}

	// Only push the actor-level material when one is actually set.
	// Passing nullptr here would wipe a material the user assigned directly
	// on the LoftMesh component slot every time the mesh rebuilds.
	if (Material)
	{
		LoftMesh->SetMaterial(0, Material);
	}

	// Cast shadow / collision are NOT forced here: the user toggles them on the
	// component and a rebuild must not undo that. Collision is only switched on
	// when this build actually generated collision geometry.
	if (bCreateCollision)
	{
		LoftMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	}

	LastHash = ComputeSettingsHash();
}

void ASplineLoftActor::UsePipeProfile(float InRadius, int32 Segments)
{
	ProfileType = ESplineLoftProfileType::Pipe;
	Radius = FMath::Max(InRadius, 0.1f);
	RadialSegments = FMath::Clamp(Segments, 3, 128);
	RebuildLoft();
}

void ASplineLoftActor::UseBoxProfile(float InWidth, float InHeight, float Bevel, int32 BevelSeg)
{
	ProfileType = ESplineLoftProfileType::Box;
	Width = FMath::Max(InWidth, 0.1f);
	Height = FMath::Max(InHeight, 0.1f);
	BevelRadius = FMath::Max(Bevel, 0.f);
	BevelSegments = FMath::Clamp(BevelSeg, 1, 16);
	RebuildLoft();
}

void ASplineLoftActor::UseRibbonProfile(float InWidth, bool bVertical)
{
	ProfileType = bVertical ? ESplineLoftProfileType::RibbonVertical : ESplineLoftProfileType::Ribbon;
	if (bVertical)
	{
		Height = FMath::Max(InWidth, 0.1f);
	}
	else
	{
		Width = FMath::Max(InWidth, 0.1f);
	}

	// A flat strip has no thickness to hide a miter fan behind, and mitering pushes the
	// inner edge past the turn radius much earlier. Keep the corner stretch small.
	MiterLimit = FMath::Min(MiterLimit, 1.5f);
	CornerMode = ESplineLoftCornerMode::Trim;

	RebuildLoft();
}

void ASplineLoftActor::UseHalfPipeProfile(float InRadius, float InThickness, int32 Segments)
{
	ProfileType = ESplineLoftProfileType::HalfPipe;
	Radius = FMath::Max(InRadius, 0.1f);
	Thickness = FMath::Max(InThickness, 0.f);
	RadialSegments = FMath::Clamp(Segments, 3, 128);
	RebuildLoft();
}

void ASplineLoftActor::UseCustomProfile(const TArray<FVector2D>& Points, bool bClosed)
{
	if (Points.Num() < 2)
	{
		return;
	}
	ProfileType = ESplineLoftProfileType::Custom;
	CustomProfile = Points;
	bClosedCustomProfile = bClosed && Points.Num() > 2;
	RebuildLoft();
}

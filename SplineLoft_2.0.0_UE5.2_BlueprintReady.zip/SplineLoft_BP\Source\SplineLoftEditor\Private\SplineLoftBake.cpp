#include "SplineLoftBake.h"

#include "HAL/IConsoleManager.h"
#include "Editor.h"
#include "Engine/World.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "Components/StaticMeshComponent.h"
#include "Materials/MaterialInterface.h"
#include "MeshDescription.h"
#include "StaticMeshAttributes.h"
#include "Misc/PackageName.h"
#include "UObject/Package.h"
#include "UObject/SavePackage.h"
#include "ProceduralMeshComponent.h"
#include "SplineLoftActor.h"
#include "Engine/Selection.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "Modules/ModuleManager.h"
#include "AssetRegistry/AssetRegistryModule.h"

DEFINE_LOG_CATEGORY_STATIC(LogSplineLoftBake, Log, All);

namespace
{
    /** Same dialog the engine's "Create Static Mesh" button uses (path + asset name). */
    bool PromptForAssetPath(ASplineLoftActor* Actor, FString& OutPackageName, FString& OutAssetName)
    {
        FContentBrowserModule& ContentBrowser = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");

        FSaveAssetDialogConfig Config;
        Config.DialogTitleOverride = FText::FromString(TEXT("Save the baked static mesh"));
        Config.DefaultPath = TEXT("/Game/SplineLoftBaked");
        Config.DefaultAssetName = FString::Printf(TEXT("SM_%s"), *Actor->GetActorLabel());
        Config.ExistingAssetPolicy = ESaveAssetDialogExistingAssetPolicy::AllowButWarn;

        const FString SaveObjectPath = ContentBrowser.Get().CreateModalSaveAssetDialog(Config);
        if (SaveObjectPath.IsEmpty())
        {
            return false;
        }

        // "/Game/Foo/SM_Bar.SM_Bar"
        FString PackageName = SaveObjectPath;
        int32 DotIndex = INDEX_NONE;
        if (PackageName.FindLastChar(TEXT('.'), DotIndex))
        {
            PackageName = PackageName.Left(DotIndex);
        }
        OutPackageName = PackageName;
        OutAssetName = FPackageName::GetShortName(PackageName);
        return true;
    }

    UStaticMesh* BuildSectionInternal(UProceduralMeshComponent* MeshComp, int32 SectionIndex, const FString& PackageName, const FString& AssetName)
    {
        if (!MeshComp || MeshComp->GetNumSections() <= SectionIndex)
        {
            return nullptr;
        }

        const FProcMeshSection* Section = MeshComp->GetProcMeshSection(SectionIndex);
        if (!Section || Section->ProcVertexBuffer.Num() == 0 || Section->ProcIndexBuffer.Num() < 3)
        {
            return nullptr;
        }

        UPackage* Package = CreatePackage(*PackageName);
        if (!Package)
        {
            return nullptr;
        }

        UStaticMesh* StaticMesh = NewObject<UStaticMesh>(Package, *AssetName, RF_Public | RF_Standalone);
        if (!StaticMesh)
        {
            return nullptr;
        }

        FMeshDescription MeshDescription;
        FStaticMeshAttributes Attributes(MeshDescription);
        Attributes.Register();
        Attributes.GetVertexInstanceUVs().SetNumChannels(2);

        const FPolygonGroupID Group = MeshDescription.CreatePolygonGroup();

        // Shared vertices keep the surface smooth; degenerate triangles are dropped because
        // a vertex registered twice inside one polygon trips an assert.
        // Weld only vertices that share BOTH position and normal. Welding across a hard edge
        // smooths the crease and the corner reads as a different (reversed) curvature.
        TMap<uint64, FVertexID> VertexMap;

        TArray<FVertexInstanceID> InstanceIds;
        InstanceIds.SetNum(3);

        for (int32 Tri = 0; Tri + 2 < Section->ProcIndexBuffer.Num(); Tri += 3)
        {
            uint64 Keys[3];
            const FProcMeshVertex* Corners[3];
            bool bValid = true;

            for (int32 Corner = 0; Corner < 3; ++Corner)
            {
                const int32 VertexIndex = Section->ProcIndexBuffer[Tri + Corner];
                if (!Section->ProcVertexBuffer.IsValidIndex(VertexIndex))
                {
                    bValid = false;
                    break;
                }

                const FProcMeshVertex& Vertex = Section->ProcVertexBuffer[VertexIndex];
                Corners[Corner] = &Vertex;
                Keys[Corner] = HashCombine(
                    HashCombine(
                        HashCombine(GetTypeHash(FMath::RoundToInt(Vertex.Position.X * 100.f)),
                                    GetTypeHash(FMath::RoundToInt(Vertex.Position.Y * 100.f))),
                        GetTypeHash(FMath::RoundToInt(Vertex.Position.Z * 100.f))),
                    HashCombine(
                        HashCombine(GetTypeHash(FMath::RoundToInt(Vertex.Normal.X * 100.f)),
                                    GetTypeHash(FMath::RoundToInt(Vertex.Normal.Y * 100.f))),
                        GetTypeHash(FMath::RoundToInt(Vertex.Normal.Z * 100.f))));
            }

            if (!bValid || Keys[0] == Keys[1] || Keys[1] == Keys[2] || Keys[0] == Keys[2])
            {
                continue;
            }

            for (int32 Corner = 0; Corner < 3; ++Corner)
            {
                const FProcMeshVertex& Vertex = *Corners[Corner];

                FVertexID VertexId;
                if (const FVertexID* Existing = VertexMap.Find(Keys[Corner]))
                {
                    VertexId = *Existing;
                }
                else
                {
                    VertexId = MeshDescription.CreateVertex();
                    Attributes.GetVertexPositions().Set(VertexId, FVector3f(Vertex.Position));
                    VertexMap.Add(Keys[Corner], VertexId);
                }

                const FVertexInstanceID InstanceId = MeshDescription.CreateVertexInstance(VertexId);
                Attributes.GetVertexInstanceNormals().Set(InstanceId, FVector3f(Vertex.Normal));
                Attributes.GetVertexInstanceTangents().Set(InstanceId, FVector3f(Vertex.Tangent.TangentX));
                Attributes.GetVertexInstanceUVs().Set(InstanceId, 0, FVector2f(Vertex.UV0));
                Attributes.GetVertexInstanceUVs().Set(InstanceId, 1, FVector2f(Vertex.UV1));
                InstanceIds[Corner] = InstanceId;
            }

            MeshDescription.CreatePolygon(Group, InstanceIds);
        }

        if (MeshDescription.Polygons().Num() == 0)
        {
            return nullptr;
        }

        for (int32 MatIndex = 0; MatIndex < MeshComp->GetNumMaterials(); ++MatIndex)
        {
            StaticMesh->GetStaticMaterials().Add(FStaticMaterial(MeshComp->GetMaterial(MatIndex)));
        }

        UE_LOG(LogSplineLoftBake, Display, TEXT("[SplineLoft] tris: source=%d polygons=%d"), Section->ProcIndexBuffer.Num() / 3, MeshDescription.Polygons().Num());

        StaticMesh->BuildFromMeshDescriptions({ &MeshDescription });
        StaticMesh->PostEditChange();
        FAssetRegistryModule::AssetCreated(StaticMesh);

        const FString Filename = FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension());
        FSavePackageArgs SaveArgs;
        SaveArgs.TopLevelFlags = RF_Public | RF_Standalone;
        SaveArgs.SaveFlags = SAVE_NoError;
        UPackage::SavePackage(Package, StaticMesh, *Filename, SaveArgs);

        return StaticMesh;
    }
}
UStaticMesh* SplineLoftBake::BuildStaticMeshAsset(UProceduralMeshComponent* MeshComp, const FString& PackageName, const FString& AssetName)
{
    return BuildSectionInternal(MeshComp, 0, PackageName, AssetName);
}

int32 SplineLoftBake::BakeActors(const TArray<ASplineLoftActor*>& Actors, bool bPromptForPath, bool bSpawnActor)
{
    UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
    if (!World)
    {
        UE_LOG(LogSplineLoftBake, Error, TEXT("[SplineLoft] no editor world"));
        return 0;
    }

    int32 Baked = 0;
    for (ASplineLoftActor* Loft : Actors)
    {
        if (!IsValid(Loft))
        {
            continue;
        }

        UProceduralMeshComponent* MeshComp = Loft->GetLoftMesh();
        if (!MeshComp)
        {
            continue;
        }

        FString PackageName;
        FString AssetName;
        if (bPromptForPath)
        {
            if (!PromptForAssetPath(Loft, PackageName, AssetName))
            {
                continue;
            }
        }
        else
        {
            AssetName = FString::Printf(TEXT("SM_%s_%d"), *Loft->GetActorLabel(), Baked);
            PackageName = FString::Printf(TEXT("/Game/SplineLoftBaked/%s"), *AssetName);
        }

        UStaticMesh* Mesh = BuildSectionInternal(MeshComp, 0, PackageName, AssetName);
        if (!Mesh)
        {
            UE_LOG(LogSplineLoftBake, Warning, TEXT("[SplineLoft] bake failed for %s"), *Loft->GetActorLabel());
            continue;
        }

        if (!bSpawnActor) { ++Baked; continue; }

        FActorSpawnParameters SpawnParams;
        SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
        AStaticMeshActor* Spawned = World->SpawnActor<AStaticMeshActor>(
            AStaticMeshActor::StaticClass(),
            Loft->GetActorTransform(),
            SpawnParams);

        if (Spawned)
        {
            Spawned->SetActorLabel(AssetName);
            if (UStaticMeshComponent* Comp = Spawned->GetStaticMeshComponent())
            {
                Comp->SetStaticMesh(Mesh);
                Comp->SetMobility(EComponentMobility::Movable);
            }
            ++Baked;
        }

        UE_LOG(LogSplineLoftBake, Display, TEXT("[SplineLoft] baked %s -> %s"), *Loft->GetActorLabel(), *PackageName);
    }

    UE_LOG(LogSplineLoftBake, Display, TEXT("[SplineLoft] baked %d actor(s)"), Baked);
    return Baked;
}

static void SplineLoftBakeSelected()
{
    if (!GEditor)
    {
        return;
    }

    TArray<ASplineLoftActor*> Actors;
    for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
    {
        if (ASplineLoftActor* Loft = Cast<ASplineLoftActor>(*It))
        {
            Actors.Add(Loft);
        }
    }
    SplineLoftBake::BakeActors(Actors, false);
}

static FAutoConsoleCommand GSplineLoftBakeCommand(
    TEXT("SplineLoft.Bake"),
    TEXT("Bake every selected Spline Loft actor into a StaticMesh asset (no dialog) and spawn a StaticMeshActor at the same transform."),
    FConsoleCommandDelegate::CreateStatic(&SplineLoftBakeSelected));
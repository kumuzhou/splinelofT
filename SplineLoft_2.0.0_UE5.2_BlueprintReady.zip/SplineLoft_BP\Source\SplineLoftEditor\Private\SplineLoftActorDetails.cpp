#include "SplineLoftActorDetails.h"

#include "DetailCategoryBuilder.h"
#include "DetailLayoutBuilder.h"
#include "Internationalization/Internationalization.h"
#include "Internationalization/Culture.h"
#include "SplineLoftBake.h"
#include "DesktopPlatformModule.h"
#include "Misc/Paths.h"
#include "DetailWidgetRow.h"
#include "Editor.h"
#include "Engine/Selection.h"
#include "PropertyHandle.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SComboBox.h"
#include "SplineLoftActor.h"

namespace
{
	/** Editor language follows the engine; zh* gets Chinese, everything else English. */
	bool IsChinese()
	{
		if (!FInternationalization::IsAvailable())
		{
			return false;
		}
		const FString Lang = FInternationalization::Get().GetCurrentLanguage()->GetName();
		return Lang.StartsWith(TEXT("zh"));
	}

	FText Tr(const TCHAR* En, const TCHAR* Zh)
	{
		return FText::FromString(IsChinese() ? Zh : En);
	}

	struct FLocalizedProp
	{
		FName Prop;
		FName Category;
		const TCHAR* En;
		const TCHAR* Zh;
		const TCHAR* EnTip;
		const TCHAR* ZhTip;
	};
}

TSharedRef<IDetailCustomization> FSplineLoftActorDetails::MakeInstance()
{
	return MakeShareable(new FSplineLoftActorDetails());
}

void FSplineLoftActorDetails::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder)
{
	// Customizations run before the default layout, so creating the categories here with
	// Important priority pins them above the component sections.
	DetailBuilder.EditCategory("1 Profile", Tr(TEXT("Profile"), TEXT("剖面")), ECategoryPriority::Important);
	DetailBuilder.EditCategory("2 Path", Tr(TEXT("Path"), TEXT("路径")), ECategoryPriority::Important);
	DetailBuilder.EditCategory("3 UV", Tr(TEXT("UV"), TEXT("UV")), ECategoryPriority::Important);
	DetailBuilder.EditCategory("4 Mesh", Tr(TEXT("Mesh"), TEXT("网格")), ECategoryPriority::Important);

	static const FLocalizedProp Props[] =
	{
		{ TEXT("ProfileType"), TEXT("1 Profile"),
			TEXT("Profile Type"), TEXT("剖面类型"),
			TEXT("Cross-section that is swept along the spline."), TEXT("沿样条扫掠的横截面形状。") },

		{ TEXT("CustomProfile"), TEXT("1 Profile"),
			TEXT("Custom Profile Points"), TEXT("自定义剖面点"),
			TEXT("2D outline used by Profile Type = Custom. X = spline right, Y = spline up (cm)."),
			TEXT("剖面类型选 Custom 时使用的二维轮廓点。X = 样条右方向，Y = 样条上方向（厘米）。") },

		{ TEXT("bClosedCustomProfile"), TEXT("1 Profile"),
			TEXT("Custom Profile Closed"), TEXT("自定义剖面闭合"),
			TEXT("Close the outline when it has three or more points."), TEXT("三个点以上时首尾相连成闭合轮廓。") },

		{ TEXT("Radius"), TEXT("1 Profile"),
			TEXT("Radius (thickness)"), TEXT("半径（粗细）"),
			TEXT("Radius of the Pipe and Half Pipe profile."), TEXT("管道 / 半管的半径。") },

		{ TEXT("RadialSegments"), TEXT("1 Profile"),
			TEXT("Radial Segments"), TEXT("圆周段数"),
			TEXT("Segments around the Pipe and Half Pipe profile."), TEXT("管道 / 半管圆周方向的分段数。") },

		{ TEXT("Width"), TEXT("1 Profile"),
			TEXT("Width"), TEXT("宽度"),
			TEXT("Size along the spline's right axis."), TEXT("沿样条右方向的尺寸。") },

		{ TEXT("Height"), TEXT("1 Profile"),
			TEXT("Height"), TEXT("高度"),
			TEXT("Size along the spline's up axis."), TEXT("沿样条上方向的尺寸。") },

		{ TEXT("BevelRadius"), TEXT("1 Profile"),
			TEXT("Bevel Radius"), TEXT("倒角半径"),
			TEXT("Corner radius of the Box profile. 0 = sharp, 1 segment = chamfer."),
			TEXT("方管的圆角半径。0 = 直角，段数 1 = 倒角。") },

		{ TEXT("BevelSegments"), TEXT("1 Profile"),
			TEXT("Bevel Segments"), TEXT("倒角段数"),
			TEXT("Segments per box corner. 1 = chamfer, 2+ = round."), TEXT("每个角的分段数。1 = 倒角，2 以上 = 圆角。") },

		{ TEXT("Thickness"), TEXT("1 Profile"),
			TEXT("Half Pipe Thickness"), TEXT("半管壁厚"),
			TEXT("Wall thickness of the Half Pipe profile."), TEXT("半管剖面的壁厚。") },

		{ TEXT("ArcStartAngle"), TEXT("1 Profile"),
			TEXT("Arc Start Angle"), TEXT("弧起始角"),
			TEXT("Start angle of the half pipe arc."), TEXT("半管圆弧的起始角度。") },

		{ TEXT("ArcEndAngle"), TEXT("1 Profile"),
			TEXT("Arc End Angle"), TEXT("弧结束角"),
			TEXT("End angle of the half pipe arc."), TEXT("半管圆弧的结束角度。") },

		{ TEXT("ProfileScale"), TEXT("1 Profile"),
			TEXT("Profile Scale"), TEXT("剖面缩放"),
			TEXT("Uniform scale of the whole profile."), TEXT("整体缩放剖面，一个滑杆调粗细。") },

		{ TEXT("ProfileRotation"), TEXT("1 Profile"),
			TEXT("Profile Rotation"), TEXT("剖面旋转"),
			TEXT("Rotate the profile around the path in degrees."), TEXT("剖面绕路径旋转的角度（度）。") },

		{ TEXT("ProfileOffset"), TEXT("1 Profile"),
			TEXT("Profile Offset"), TEXT("剖面偏移"),
			TEXT("Shift the profile relative to the path."), TEXT("剖面相对路径的偏移。") },

		{ TEXT("bAdaptivePath"), TEXT("2 Path"),
			TEXT("Adaptive Segments"), TEXT("自适应分段"),
			TEXT("Straight runs stay coarse, curved parts get subdivided."),
			TEXT("直线段少分段，弯曲段自动细分，省面数。") },

		{ TEXT("PathTolerance"), TEXT("2 Path"),
			TEXT("Curve Tolerance (cm)"), TEXT("曲线容差（厘米）"),
			TEXT("Maximum deviation from the real curve. Smaller = more rings."),
			TEXT("与真实曲线的最大偏差。越小越贴合、面数越多。") },

		{ TEXT("PathStep"), TEXT("2 Path"),
			TEXT("Path Step"), TEXT("分段间距"),
			TEXT("Ring spacing when Adaptive Segments is off."), TEXT("关闭自适应时的固定分段间距。") },

		{ TEXT("MiterLimit"), TEXT("2 Path"),
			TEXT("Miter Limit"), TEXT("斜接上限"),
			TEXT("Clamp for the miter stretch. 90 degree corners need at least 1.414."),
			TEXT("拐角斜接的拉伸上限。90 度拐角至少需要 1.414。") },


		{ TEXT("UVMode"), TEXT("3 UV"),
			TEXT("UV Mode"), TEXT("UV 模式"),
			TEXT("Normalized = one UV for the whole model; World Tiling = repeat by length."),
			TEXT("Normalized = 整个模型一套 0-1 UV；World Tiling = 按长度平铺。") },

		{ TEXT("TileU"), TEXT("3 UV"),
			TEXT("Tile U"), TEXT("U 平铺长度"),
			TEXT("Texture length across the profile in world tiling mode."), TEXT("平铺模式下 U 方向一张贴图覆盖多少厘米。") },

		{ TEXT("TileV"), TEXT("3 UV"),
			TEXT("Tile V"), TEXT("V 平铺长度"),
			TEXT("Texture length along the spline in world tiling mode."), TEXT("平铺模式下 V 方向一张贴图覆盖多少厘米。") },

		{ TEXT("Material"), TEXT("4 Mesh"),
			TEXT("Material"), TEXT("材质"),
			TEXT("Applied to the generated mesh."), TEXT("应用到生成网格的材质。") },

		{ TEXT("bCreateCollision"), TEXT("4 Mesh"),
			TEXT("Create Collision"), TEXT("生成碰撞"),
			TEXT("Procedural mesh collision is expensive - leave off for effects."),
			TEXT("程序化网格的碰撞很贵，特效建议关闭。") },

		{ TEXT("bFlipWinding"), TEXT("4 Mesh"),
			TEXT("Flip Winding"), TEXT("翻转面朝向"),
			TEXT("Reverse the triangle order if the surface renders inside out."),
			TEXT("如果模型内外反了，勾选这里翻转三角面顺序。") },

		{ TEXT("bFlipNormals"), TEXT("4 Mesh"),
			TEXT("Flip Normals"), TEXT("翻转法线"),
			TEXT("Reverse the vertex normals only."), TEXT("只翻转法线方向，不改三角形。") },
	};

	for (const FLocalizedProp& P : Props)
	{
		TSharedRef<IPropertyHandle> Handle = DetailBuilder.GetProperty(P.Prop, ASplineLoftActor::StaticClass());
		if (!Handle->IsValidHandle())
		{
			continue;
		}
		IDetailCategoryBuilder& Category = DetailBuilder.EditCategory(P.Category);
		Category.AddProperty(Handle)
			.DisplayName(Tr(P.En, P.Zh))
			.ToolTip(Tr(P.EnTip, P.ZhTip));
	}


	// Corner mode: localized combo (enum entry metadata cannot be translated).
	TSharedRef<IPropertyHandle> CornerHandle = DetailBuilder.GetProperty(GET_MEMBER_NAME_CHECKED(ASplineLoftActor, CornerMode), ASplineLoftActor::StaticClass());
	DetailBuilder.HideProperty(CornerHandle);

	struct FCornerCombo
	{
		TArray<TSharedPtr<FString>> Items;
		TSharedPtr<FString> Selected;
	};

	TSharedRef<FCornerCombo> Combo = MakeShared<FCornerCombo>();
	Combo->Items.Add(MakeShared<FString>(Tr(TEXT("Miter (sharp, may self-intersect)"), TEXT("斜接（保形，内侧可能自穿）")).ToString()));
	Combo->Items.Add(MakeShared<FString>(Tr(TEXT("Trim (cuts the inner side)"), TEXT("裁剪（切内侧，不交叉）")).ToString()));

	uint8 CornerValue = 0;
	CornerHandle->GetValue(CornerValue);
	Combo->Selected = Combo->Items[FMath::Clamp<int32>((int32)CornerValue, 0, Combo->Items.Num() - 1)];

	DetailBuilder.EditCategory("2 Path")
		.AddCustomRow(Tr(TEXT("Corner Mode"), TEXT("拐角模式")))
		.NameContent()
		[
			SNew(STextBlock).Text(Tr(TEXT("Corner Mode"), TEXT("拐角模式"))).Font(IDetailLayoutBuilder::GetDetailFont())
		]
		.ValueContent()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&Combo->Items)
			.InitiallySelectedItem(Combo->Selected)
			.OnGenerateWidget_Lambda([](TSharedPtr<FString> Item)
			{
				return SNew(STextBlock).Text(FText::FromString(Item.IsValid() ? *Item : FString()));
			})
			.OnSelectionChanged_Lambda([Combo, CornerHandle](TSharedPtr<FString> Item, ESelectInfo::Type)
			{
				Combo->Selected = Item;
				const int32 Index = Combo->Items.IndexOfByKey(Item);
				if (Index != INDEX_NONE)
				{
					CornerHandle->SetValue((uint8)Index);
				}
			})
			.Content()
			[
				SNew(STextBlock).Text_Lambda([Combo]()
				{
					return FText::FromString(Combo->Selected.IsValid() ? *Combo->Selected : FString());
				})
			]
		];


	auto BakeSelected = [](bool bSpawnActor)
	{
		TArray<ASplineLoftActor*> Actors;
		if (GEditor)
		{
			for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
			{
				if (ASplineLoftActor* Loft = Cast<ASplineLoftActor>(*It))
				{
					Actors.Add(Loft);
				}
			}
		}
		SplineLoftBake::BakeActors(Actors, true, bSpawnActor);
	};

	DetailBuilder.EditCategory("4 Mesh")
		.AddCustomRow(Tr(TEXT("CreateMesh"), TEXT("创建网格体")))
		.WholeRowContent()
		[
			SNew(SHorizontalBox)

			+ SHorizontalBox::Slot()
			.FillWidth(1.f)
			.Padding(0.f, 0.f, 2.f, 0.f)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.Text(Tr(TEXT("Create Static Mesh"), TEXT("创建静态网格体")))
				.ToolTipText(Tr(
					TEXT("Bakes the mesh into a StaticMesh asset. Nothing is added to the level."),
					TEXT("把当前网格烘焙成静态网格资产，不往关卡里放任何东西。")))
				.OnClicked_Lambda([]()
				{
					TArray<ASplineLoftActor*> Actors;
					if (GEditor)
					{
						for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
						{
							if (ASplineLoftActor* Loft = Cast<ASplineLoftActor>(*It))
							{
								Actors.Add(Loft);
							}
						}
					}
					SplineLoftBake::BakeActors(Actors, true, false);
					return FReply::Handled();
				})
			]

			+ SHorizontalBox::Slot()
			.FillWidth(1.f)
			.Padding(2.f, 0.f, 0.f, 0.f)
			[
				SNew(SButton)
				.HAlign(HAlign_Center)
				.Text(Tr(TEXT("Create + Actor"), TEXT("创建 + 生成 Actor")))
				.ToolTipText(Tr(
					TEXT("Bakes the mesh and spawns a StaticMeshActor with the same name at the same transform."),
					TEXT("烘焙成静态网格资产，并在同一位置生成一个同名的 StaticMeshActor。")))
				.OnClicked_Lambda([]()
				{
					TArray<ASplineLoftActor*> Actors;
					if (GEditor)
					{
						for (FSelectionIterator It(GEditor->GetSelectedActorIterator()); It; ++It)
						{
							if (ASplineLoftActor* Loft = Cast<ASplineLoftActor>(*It))
							{
								Actors.Add(Loft);
							}
						}
					}
					SplineLoftBake::BakeActors(Actors, true, true);
					return FReply::Handled();
				})
			]
		];
	// Component references live in the Components tree.
	DetailBuilder.HideProperty(GET_MEMBER_NAME_CHECKED(ASplineLoftActor, Spline));
	DetailBuilder.HideProperty(GET_MEMBER_NAME_CHECKED(ASplineLoftActor, LoftMesh));

	// Options that only belong to the hidden corner modes.
	DetailBuilder.HideProperty(GET_MEMBER_NAME_CHECKED(ASplineLoftActor, TrimTolerance));
}

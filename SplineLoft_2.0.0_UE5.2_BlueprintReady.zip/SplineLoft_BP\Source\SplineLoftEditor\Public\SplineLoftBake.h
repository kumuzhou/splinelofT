#pragma once

#include "CoreMinimal.h"

class ASplineLoftActor;
class UProceduralMeshComponent;
class UStaticMesh;

namespace SplineLoftBake
{
	/**
	 * Bakes every actor's procedural mesh into a StaticMesh asset and spawns a StaticMeshActor
	 * at the same world transform. The source actors are left untouched.
	 * @param bPromptForPath  show the same path + name dialog the engine uses for
	 *                        "Create Static Mesh"; when false a default folder is used.
	 * @return number of actors that were baked.
	 */
	/** Builds a UStaticMesh asset from a procedural mesh section (used by the self test). */
	UStaticMesh* BuildStaticMeshAsset(UProceduralMeshComponent* MeshComp, const FString& PackageName, const FString& AssetName);

	int32 BakeActors(const TArray<ASplineLoftActor*>& Actors, bool bPromptForPath = true, bool bSpawnActor = true);
}
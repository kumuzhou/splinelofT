> English documentation: [README_EN.md](README_EN.md)

# Spline Loft — 样条线倒角剖面放样（UE 5.2 插件）

把一条 **2D 剖面**（带倒角/圆角的截面）沿 `USplineComponent` 扫掠成**一整块连续网格**，
相当于 3ds Max 的 *Bevel Profile*，但结果是一块干净的程序化网格：

- 转角只生成**一圈环**（斜接 miter），不会出现两段互相插进去的重叠面；
- UV 按**弧长**生成，弯曲、分段、变长都不拉伸；
- 法线解析计算：方管的棱是硬边，倒角是平滑的；
- 一个 `ProceduralMeshComponent` = 一次 DrawCall，不再每段一个组件 + 一个动态材质实例。

插件里带一个**可直接放置的 Actor**：启用插件后，在 *放置 Actor* 面板会出现 **Spline Loft** 分类。

---

## 1. 目录结构

```
Plugins/SplineLoft/
├─ SplineLoft.uplugin
├─ Content/                      # 预留：蓝图预设 / 示例都放这里（挂载为 /SplineLoft/）
└─ Source/
   ├─ SplineLoft/                # Runtime
   │  ├─ Public/SplineLoftActor.h        # ASplineLoftActor（样条 + 程序化网格 + 参数）
   │  ├─ Public/SplineLoftLibrary.h      # 纯函数库：BuildLoftMesh / 剖面预设
   │  └─ Private/...
   └─ SplineLoftEditor/          # Editor
      ├─ Public/SplineLoftActorFactory.h # 专用 ActorFactory（让没有资产的 C++ Actor 可拖放）
      └─ Private/SplineLoftEditorModule.cpp # 注册 "Spline Loft" 放置分类
```

两个模块：

| 模块 | 类型 | 作用 |
|---|---|---|
| `SplineLoft` | Runtime | Actor、网格生成、剖面预设 |
| `SplineLoftEditor` | Editor | 放置面板分类 + ActorFactory，**打包时不会进游戏** |

依赖的 `ProceduralMeshComponent` 是引擎自带插件，`.uplugin` 里已声明，启用本插件时会自动启用。

---

## 2. 安装 / 编译

把整个 `SplineLoft` 文件夹放到工程的 `Plugins/` 下，然后：

- 有 C++ 工程：重新生成工程文件 → 编译（或 `Build.bat YourProjectEditor Win64 Development -Project="...uproject"`）
- 首次打开编辑器会提示重新编译模块，选"是"

> 已在 **UE 5.2 + VS2019** 上编译通过，并用无头编辑器做了启动冒烟测试（插件挂载、内容挂载点 `/SplineLoft/` 注册、无报错）。

---

## 3. 使用

### 3.1 放置

1. 打开 **窗口 → 放置 Actor**（Place Actors）
2. 左侧分类里选 **Spline Loft**，把 **Spline Loft** 拖进场景
3. 拖拽样条点 —— 网格**实时**跟着变（编辑器内每帧比对参数哈希，变了就重建）

也可以直接在世界大纲里复制/粘贴，或用蓝图 `Spawn Actor from Class → Spline Loft`。

### 3.2 参数

选中 Actor，Details 面板：

| 分组 | 参数 | 说明 |
|---|---|---|
| Profile | Profile Type | Pipe / Box / Half Pipe / Ribbon / Ribbon(vertical) / Custom |
| | **Custom Profile Points** | Custom 模式的 2D 轮廓点（X=右，Y=上，cm），点 `+` 添加；默认已填 100×100 方块 |
| | Custom Profile Closed | 3 点以上是否首尾相连 |
| | Radius (thickness)、Radial Segments | 管道、半管 |
| | Width、Height | 方管、片 |
| | Bevel Radius、Bevel Segments | **倒角**：半径=0 直角，段数=1 倒角，≥2 圆角 |
| | Thickness | 半管壁厚，0 = 开口弧 |
| | Arc Start / End Angle | 半管角度范围 |
| | **Profile Scale** | 整个剖面的统一缩放，一个滑杆调"粗细" |
| | Custom Profile + Closed | 自定义 2D 点（X=右，Y=上），闭合时自动纠正为 CCW |
| | Profile Rotation / Offset | 剖面绕路径旋转 / 偏离路径 |
| Path | Adaptive Segments | 按曲率自适应分段：直线只留 2 圈，只有曲线才细分（默认开） |
| | Curve Tolerance (cm) | 与真实曲线的最大偏差，越小曲线越密 |
| | Path Step | 关掉自适应时的固定间距 |
| | Corner Mode | **Trim**（默认，只裁内角）/ Miter（纯斜接，会自交）/ Shrink（整体收窄） |
| | Trim Strength | Trim 时保留多少曲率半径，**越小切得越深**（默认 0.5，常用 0.3~0.7） |
| | Min Width Scale | Shrink 模式下的收窄下限 |
| UV | UV Mode | **Normalized**（默认）= 整个模型 0..1；World Tiling = 按世界长度平铺 |
| | Tile U / Tile V | 仅 World Tiling 模式生效，一张贴图覆盖多少 cm |
| Mesh | Material | 只设一次，不用逐段 MID（留空则用组件槽位上的材质） |
| | Create Collision / Flip Winding / Flip Normals | 阴影不在这里：直接勾 LoftMesh 组件的「投射阴影」 |

Details 里还有 **Rebuild Loft** 按钮（`CallInEditor`），自动更新失效时手动重建。

> 材质、投射阴影、碰撞响应**只属于组件**：重建不会覆盖它们。Actor 上的 `Material` 为空时，
> 你在 LoftMesh 组件槽位挂的材质会一直保留。

### 3.2.0 剖面预设（蓝图里一行切换）

不想手动改一堆参数时，直接调这几个函数（自带参数并立即重建）：

| 函数 | 说明 |
|---|---|
| `UsePipeProfile(Radius, Segments)` | 圆管 |
| `UseBoxProfile(Width, Height, Bevel, BevelSeg)` | 方管 / 倒角方管 |
| `UseRibbonProfile(Width, bVertical)` | 片（横 / 竖） |
| `UseHalfPipeProfile(Radius, Thickness, Segments)` | 半管 |
| `UseCustomProfile(Points, bClosed)` | 自定义 2D 轮廓 |

典型用法：`Switch on 模型选择` → 分别接 4 个 `Use*Profile`，就能在同一个 Actor 上切"管道 / 方管 / 片 / 半管"。

> Details 面板里 **Profile / Path / UV / Mesh 四个分类被固定在组件区之上**（`SplineLoftActorDetails`
> 用 `ECategoryPriority::Important` 提前注册），不用再滚到底部找参数。


> 面板里**没有任何 EditCondition**：所有尺寸参数恒定可见、可调，不会因为切了剖面类型而变灰或消失。

### 3.2.1 自检命令

编辑器控制台（`~`）里执行：

```
SplineLoft.SelfTest
```

会依次用 Box / Pipe / HalfPipe / Ribbon / Pipe×2 重建，并在 Output Log 打印顶点数、三角数和包围盒：

```
[SplineLoft] Box 200x100      verts= 945 tris= 832 extent=(451.6, 272.2, 50.0)
[SplineLoft] Pipe r30 /24     verts=2625 tris=4992 extent=(450.5, 202.2, 30.0)
[SplineLoft] Pipe r30 /48     verts=5145 tris=9984 extent=(450.5, 202.2, 30.0)
[SplineLoft] HalfPipe r100    verts=10815 tris=20384 extent=(451.7, 277.2, 52.5)
[SplineLoft] Ribbon w200      verts= 210 tris= 208 extent=(451.6, 272.2, 0.0)
[SplineLoft] Pipe r30 x2      verts=5145 tris=9984 extent=(451.0, 232.2, 60.0)
```

`extent` 的 Z 就是剖面高度的一半：方管 100 高 → 50，管半径 30 → 30，×2 → 60。
如果这些数字对，说明参数链路是通的，问题只在显示/材质上。

### 3.3 材质

- `UV0`：
  - `UV Mode = Normalized`（默认）：**整条样条 + 整个剖面 = 一个 0..1 UV**，一张图铺满整个模型，不重复；
  - `UV Mode = World Tiling`：`(剖面弧长/TileU, 路径弧长/TileV)`，按世界长度平铺。
- `UV1 = (0..1 剖面, 0..1 路径)`：永远归一化，做整条样条的渐变（与 UV Mode 无关）。
- 开口剖面（Ribbon / Thickness=0 的半管）材质要**双面**。

---

## 4. 纯蓝图 / 自定义网格

`USplineLoftLibrary` 里的函数都是 `BlueprintCallable`，想在自己的 Actor/组件里生成时：

```
Switch on 模型 → MakeCircleProfile / MakeRectProfile / MakeArcProfile
              ↓
        BuildLoftMesh(TargetMesh, Spline, Profile, Options)
```

| 函数 | 说明 |
|---|---|
| `BuildLoftMesh(TargetMesh, Spline, Profile, Options, SectionIndex)` | 生成/替换一个 section，返回是否成功 |
| `ClearLoftMesh(TargetMesh, SectionIndex)` | 清 section（-1 = 全清） |
| `GetProfileLength(Profile, bClosed)` | 剖面周长，可直接当 TileU |
| `MakeCircleProfile(R, Seg)` | 圆 |
| `MakeRectProfile(W, H, Bevel, Seg)` | 带倒角矩形 |
| `MakeArcProfile(R, T, A0, A1, Seg)` | 弧 / 半管壳 |

---

## 5. 做成 FAB 商品

### 5.1 加蓝图资产（可选，但建议）

C++ Actor 已经能"新建即用"，如果想让买家拖一个**蓝图**就能用（也方便你在里面预置参数）：

1. 内容浏览器 → 右键 → **蓝图类** → 搜索 `Spline Loft` → 命名 `BP_SplineLoft`
2. 打开它，把 Profile Type / 尺寸 / 材质按预设调好（例如 `BP_SplineLoft_Pipe`、`_Box`、`_Ribbon`）
3. **文件 → 另存为**，保存到 `Plugins/SplineLoft/Content/Blueprints/`（对应 `/SplineLoft/Blueprints/`）
4. 顺便做一张演示关卡 `Content/Maps/Demo.umap`，FAB 商品页截图也从这里出

> 这些是二进制 `.uasset`，必须在编辑器里生成；本插件已经 `CanContainContent: true`，
> `Content/` 目录挂载为 `/SplineLoft/`，存进去就能随插件分发。

### 5.2 打包清单

- [ ] 只保留 `SplineLoft.uplugin`、`Source/`、`Content/`；**删掉** `Binaries/`、`Intermediate/`、`Saved/`
- [ ] `.uplugin` 填好 `FriendlyName`、`Description`、`VersionName`、`EngineVersion`、`CreatedBy`、`DocsURL`、`SupportURL`
- [ ] `Category` 建议 `Geometry`
- [ ] 源码要为每个目标引擎版本能编译（FAB 的代码插件是发源码、由买家编译）
- [ ] 不要把本机绝对路径写进 `.uplugin` / `.Build.cs`
- [ ] 商品页需要：图标、3~5 张截图、演示视频、文档链接
- [ ] 首次提交建议 `IsBetaVersion: false`、`Version: 1`

---

## 6. 已知限制

- 三角面朝向：UE 的正面是**屏幕空间顺时针**。生成器默认已按这个约定输出；
  如果你自己改过生成代码或反向移植，出现"内外翻"，勾 `Flip Winding` 即可（只翻绕序，不动法线）。
- `ProceduralMeshComponent` **不支持 Nanite**；需要 Nanite 就在编辑器里把结果烘成 StaticMesh。
- 斜接只在同一圈环上做，没有"转角圆角化"（3ds Max 的 *Beveled mitering*）。
  剖面比转弯半径大时内壁一定会自交，这是几何必然 —— 减小剖面或给路径加圆角点。
- 闭合路径的剖面接缝会复制一圈顶点（为了 UV 连续），顶点数会略多。
- 不要对 Actor 做非等比缩放，法线会歪。
- 放置面板分类用的是 5.2 的 `FPlacementCategoryInfo` 签名，换引擎版本若编译报错，按新版签名调整 `SplineLoftEditorModule.cpp`。

---

## 7. 常见问题

**「创建 StaticMesh」按钮是灰的**

这个按钮是引擎自带的（`FProceduralMeshComponentDetails`），启用条件只有一条：
**当前选中的对象本身就是 `UProceduralMeshComponent` 实例**，而且不是 template。

- 在**蓝图编辑器**里选中组件 → 永远是灰的（BP 里的组件是模板）
- 在关卡里要选中 **LoftMesh 组件**（不是 Actor、也不是 Spline 组件）

**「投射阴影」勾不上**

旧版每次重建都会 `SetCastShadow()`，把勾选刷回 false。现在重建**不再碰阴影和碰撞响应**，
直接在 LoftMesh 组件上勾即可；Actor 上也没有对应的属性了，不存在两处打架。

**会不会一直 tick 吃性能**

- 打包后构造函数里 `bCanEverTick = false`，**运行时完全不 tick**；
- 编辑器里只对**当前选中的** Actor 做一次参数哈希（点数组 + 十几个 float），微秒级；
  哈希变了才真正重建。

**改了 Profile Type 还是方管**

- 确认改的是**关卡里的实例**，不是蓝图编辑器的 Class Defaults（改默认值不会重建已存在的实例）；
- 改完点一下 Details 里的 **Rebuild Loft**；
- 如果还不行，控制台跑 `SplineLoft.SelfTest`，把 `[SplineLoft] Box/Pipe/...` 那几行发我。

**飘带（片）的面是反的**

开口剖面没有"内外"之分，法线方向完全由点的排列方向决定：

- `Ribbon` 现在是 `(+W/2) → (-W/2)`，法线朝 **上**（`n0=(0,0,1)`）；
- `Ribbon (vertical)` 是 `(底) → (顶)`，法线朝**样条右侧**。

想让片的正面朝另一边：**同时勾** `Flip Normals` 和 `Flip Winding`。
只勾一个会变成"能看见但受光反"或"看不见"，因为绕序和法线是两个独立的东西。

**急弯处有交叉面 / 扇形**

偏移曲线的自交是扫掠的固有性质：站点环在弯道内侧的偏移量一旦超过**局部曲率半径**，
内侧边缘就会反向，相邻两环互相穿过。

`Corner Mode` 三个选项：

| 模式 | 行为 | 代价 |
|---|---|---|
| **`Trim`（默认）** | 标准**偏移曲线自交裁剪**：求内侧偏移线的自交点，把被围住的环塌陷到交点上 | 内侧收成一个点，外角完全不动 |
| `Miter` | 纯斜接，保持完整宽度 | 急弯处会自交（扇形交叉） |
| `Shrink` | 整体等比缩小剖面 | 急弯处整条变细 |

`Trim` 的实现（和 CAD 里 offset 曲线的局部环裁剪是同一套思路）：

```
1) 逐站算内侧边界点  B_i = P_i + innerDir_i × (剖面半径 × 斜接系数)
2) 两两求线段最近点；距离 < 容差 视为自交
3) 交点 = 两条线段的最近点中点
4) 把被围住的站点 [a+1, c] 的内侧顶点按比例塌陷到该交点
```

容差默认取 `2% × 剖面半径`（可用 `Trim Tolerance` 覆盖）。

> 为什么这样做：扫掠面的自交只发生在**内侧偏移曲线**上，外角永远是合法的。
> 所以只要把内侧的局部环裁掉，面就不会再互相穿过，同时外轮廓保持原样。

曲率半径用**固定长度探针**测量（探针长度 = 剖面半径），和分段密度无关：

```
R ≈ 半个探针长度 / 探针两端的转角
```

这一点很关键：自适应采样是二分细分，相邻站点长度会按 2 的幂跳变（100/50/25…），
如果用"相邻站点间距"估半径，夹紧量就会一站一跳，内角出现台阶。
固定探针让它沿拐角连续变化。

`Trim` 的数学依据：偏移量 ≤ 曲率半径时，偏移曲线不会反向，所以内角最多被"削平"，不会交叉。
外角不加任何限制，所以斜接尖角原样保留。

曲率半径用**固定长度探针**测量（探针长度 = 剖面半径），和分段密度无关：

```
R ≈ 半个探针长度 / 探针两端的转角
```

这一点很关键：自适应采样是二分细分，相邻站点长度会按 2 的幂跳变（100/50/25…），
如果用"相邻站点间距"估半径，夹紧量就会一站一跳，内角出现台阶。
固定探针让它沿拐角连续变化。

**面数太多 / 直线上浪费分段**

`Adaptive Segments`（默认开）用弦高误差细分：直线段偏差为 0，直接收敛到 **2 圈**；
只有弯曲部分才继续细分，误差阈值是 `Curve Tolerance`（默认 0.5cm）。
同一条样条上，面数通常是原来的 1/3 左右。

**改了分段数 UV 会变吗**

不会。`UV0.V = 路径弧长 / 总长`，`UV0.U = 剖面弧长 / 剖面周长`，
两者都只跟**弧长**有关，跟分段数量、疏密完全无关——加多少圈，贴图密度都不变。

---

## 预编译二进制

包内含 **UE 5.2 / Win64** 的预编译 DLL，纯蓝图工程可以直接加载，不需要装 Visual Studio。
如果你的引擎小版本不一致，UE 会提示一次重建模块，点「是」即可（需 VS2022 + C++ 工作负载）。

## FAB 上架准备

### 1. 打包验证（必做）

关闭所有 UnrealEditor 进程后，在命令行执行：

```
"C:\Program Files\Epic Games\UE_5.2\Engine\Build\BatchFiles\RunUAT.bat" BuildPlugin ^
  -Plugin="<项目>\Plugins\SplineLoft\SplineLoft.uplugin" ^
  -Package="<输出目录>\SplineLoft" -TargetPlatforms=Win64 ^
  -Rocket
```

输出的目录就是可以上传的插件包（只含源码 + .uplugin，不含 Binaries/Intermediate）。
上传前确认 `SplineLoft.uplugin` 里没有 `"Installed": true`、`CreatedBy` 填的是你的工作室名、`SupportURL` 填一个可用的地址。

### 2. 需要自己补的两处

- `SplineLoft.uplugin` 的 `CreatedBy`（当前是占位 `SplineLoft`）
- `DocsURL` / `SupportURL`（可留空，但 FAB 审核更倾向于有）

### 3. FAB 商品页素材

- 3-5 张截图：管道、飘带、方管拐角、烘焙后的静态网格
- 1 段 15-30 秒 GIF/视频：拖入样条 → 改参数 → 实时重建
- 标题建议：`Spline Loft - Bevel Profile`
- 关键词：spline, loft, sweep, bevel, profile, extrusion, procedural

### 4. 提交前自查

- [ ] 全新空项目里启用插件，能正常放置 Actor
- [ ] 打包后的插件能编译（BuildPlugin 通过）
- [ ] 没有 Debug 专用代码在 Shipping 下被引用（SelfTest 控制台命令只在 Editor 模块）
- [ ] Content 目录为空也没关系，但 `CanContainContent: true` 要保留

using UnrealBuildTool;

public class SplineLoftEditor : ModuleRules
{
	public SplineLoftEditor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"MeshDescription",
			"StaticMeshDescription",
			"Core",
			"CoreUObject",
			"Engine",
			"SplineLoft"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"UnrealEd",
			"PlacementMode",
			"ProceduralMeshComponent",
			"PropertyEditor",
			"Slate",
			"SlateCore",
			"InputCore",
			"DesktopPlatform",
			"ContentBrowser",
			"EditorSubsystem"
		});
	}
}

#include "SplineLoftEditorModule.h"

#include "SplineLoftActor.h"
#include "SplineLoftActorDetails.h"
#include "SplineLoftActorFactory.h"
#include "Styling/AppStyle.h"
#include "Editor.h"
#include "Modules/ModuleManager.h"
#include "PropertyEditorModule.h"

#define LOCTEXT_NAMESPACE "SplineLoft"

void FSplineLoftEditorModule::StartupModule()
{
	// Placement mode needs a live editor (GEditor owns the actor factory list).
	if (!GEditor)
	{
		return;
	}

	IPlacementModeModule& PlacementMode = IPlacementModeModule::Get();

	const FPlacementCategoryInfo CategoryInfo(
		LOCTEXT("SplineLoftCategory", "Spline Loft"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "PlacementBrowser.Icons.Basic"),
		TEXT("SplineLoft"),
		TEXT("PMSplineLoft"),
		26);

	bCategoryRegistered = PlacementMode.RegisterPlacementCategory(CategoryInfo);
	if (!bCategoryRegistered)
	{
		return;
	}

	const TSharedRef<FPlaceableItem> Item = MakeShareable(new FPlaceableItem(*ASplineLoftActor::StaticClass()));
	PlaceableItems.Add(PlacementMode.RegisterPlaceableItem(TEXT("SplineLoft"), Item));

	// Details panel layout: our categories go above the component sections.
	if (FModuleManager::Get().IsModuleLoaded(TEXT("PropertyEditor")))
	{
		FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(TEXT("PropertyEditor"));
		PropertyModule.RegisterCustomClassLayout(
			ASplineLoftActor::StaticClass()->GetFName(),
			FOnGetDetailCustomizationInstance::CreateStatic(&FSplineLoftActorDetails::MakeInstance));
		PropertyModule.NotifyCustomizationModuleChanged();
	}
}

void FSplineLoftEditorModule::ShutdownModule()
{
	if (FModuleManager::Get().IsModuleLoaded(TEXT("PropertyEditor")))
	{
		FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>(TEXT("PropertyEditor"));
		PropertyModule.UnregisterCustomClassLayout(ASplineLoftActor::StaticClass()->GetFName());
	}

	if (!IPlacementModeModule::IsAvailable())
	{
		return;
	}

	IPlacementModeModule& PlacementMode = IPlacementModeModule::Get();

	for (const TOptional<FPlacementModeID>& ID : PlaceableItems)
	{
		if (ID.IsSet())
		{
			PlacementMode.UnregisterPlaceableItem(ID.GetValue());
		}
	}
	PlaceableItems.Reset();

	if (bCategoryRegistered)
	{
		PlacementMode.UnregisterPlacementCategory(TEXT("SplineLoft"));
		bCategoryRegistered = false;
	}
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FSplineLoftEditorModule, SplineLoftEditor)

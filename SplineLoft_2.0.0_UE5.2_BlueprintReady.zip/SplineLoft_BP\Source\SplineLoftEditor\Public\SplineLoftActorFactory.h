#pragma once

#include "CoreMinimal.h"
#include "ActorFactories/ActorFactory.h"
#include "SplineLoftActorFactory.generated.h"

/** Dedicated factory so the actor can be dragged from the Place Actors panel without an asset. */
UCLASS()
class UActorFactorySplineLoft : public UActorFactory
{
	GENERATED_UCLASS_BODY()

public:
	virtual bool CanCreateActorFrom(const FAssetData& AssetData, FText& OutErrorMessage) override;
};

